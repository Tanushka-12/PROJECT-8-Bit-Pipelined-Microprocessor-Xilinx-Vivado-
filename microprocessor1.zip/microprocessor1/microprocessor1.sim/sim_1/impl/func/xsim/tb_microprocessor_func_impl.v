// Copyright 1986-2017 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2017.4 (win64) Build 2086221 Fri Dec 15 20:55:39 MST 2017
// Date        : Thu May 14 18:38:00 2026
// Host        : LAPTOP-IIK5MIGR running 64-bit major release  (build 9200)
// Command     : write_verilog -mode funcsim -nolib -force -file
//               E:/microprocessor1/microprocessor1.sim/sim_1/impl/func/xsim/tb_microprocessor_func_impl.v
// Design      : microprocessor_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module accumulator
   (alu_carry,
    Q,
    carry_flag_reg,
    \pin_reg[0][7] ,
    S,
    DI,
    \pin_reg[0][6] ,
    \pin_reg[0][6]_0 ,
    \pin_reg[0][6]_1 ,
    \pin_reg[0][3] ,
    \pin_reg[0][3]_0 ,
    \pin_reg[0][7]_0 ,
    \pin_reg[0][5] ,
    \pin_reg[0][4] ,
    \pin_reg[0][3]_1 ,
    \pin_reg[0][2] ,
    O,
    \pin_reg[0][7]_1 ,
    \pin_reg[0][3]_2 ,
    \pin_reg[0][7]_2 ,
    \pin_reg[0][6]_2 ,
    \pin_reg[0][5]_0 ,
    \pin_reg[0][4]_0 ,
    \pin_reg[0][2]_0 ,
    \pin_reg[0][1] ,
    \ir_out_reg[4] ,
    alu_opcode,
    pin,
    E,
    D,
    clk_IBUF_BUFG,
    AR);
  output alu_carry;
  output [7:0]Q;
  output carry_flag_reg;
  output \pin_reg[0][7] ;
  output [1:0]S;
  output [0:0]DI;
  output \pin_reg[0][6] ;
  output \pin_reg[0][6]_0 ;
  output \pin_reg[0][6]_1 ;
  output [0:0]\pin_reg[0][3] ;
  output [1:0]\pin_reg[0][3]_0 ;
  output \pin_reg[0][7]_0 ;
  output \pin_reg[0][5] ;
  output \pin_reg[0][4] ;
  output \pin_reg[0][3]_1 ;
  output \pin_reg[0][2] ;
  output [3:0]O;
  output [3:0]\pin_reg[0][7]_1 ;
  output [1:0]\pin_reg[0][3]_2 ;
  output [0:0]\pin_reg[0][7]_2 ;
  output \pin_reg[0][6]_2 ;
  output \pin_reg[0][5]_0 ;
  output \pin_reg[0][4]_0 ;
  output \pin_reg[0][2]_0 ;
  output \pin_reg[0][1] ;
  input \ir_out_reg[4] ;
  input [0:0]alu_opcode;
  input [7:0]pin;
  input [0:0]E;
  input [7:0]D;
  input clk_IBUF_BUFG;
  input [0:0]AR;

  wire [0:0]AR;
  wire [7:0]D;
  wire [0:0]DI;
  wire [0:0]E;
  wire [3:0]O;
  wire [7:0]Q;
  wire [1:0]S;
  wire \acc_out[3]_i_10_n_0 ;
  wire \acc_out[3]_i_11_n_0 ;
  wire \acc_out[3]_i_12_n_0 ;
  wire \acc_out[3]_i_9_n_0 ;
  wire \acc_out[7]_i_13_n_0 ;
  wire \acc_out[7]_i_14_n_0 ;
  wire \acc_out[7]_i_15_n_0 ;
  wire \acc_out[7]_i_16_n_0 ;
  wire \acc_out_reg[3]_i_6_n_0 ;
  wire \acc_out_reg[7]_i_9_n_0 ;
  wire alu_carry;
  wire [0:0]alu_opcode;
  wire carry_flag_reg;
  wire carry_flag_reg_i_3_n_3;
  wire clk_IBUF_BUFG;
  wire i___0_carry_i_8_n_0;
  wire \ir_out_reg[4] ;
  wire [7:0]pin;
  wire \pin_reg[0][1] ;
  wire \pin_reg[0][2] ;
  wire \pin_reg[0][2]_0 ;
  wire [0:0]\pin_reg[0][3] ;
  wire [1:0]\pin_reg[0][3]_0 ;
  wire \pin_reg[0][3]_1 ;
  wire [1:0]\pin_reg[0][3]_2 ;
  wire \pin_reg[0][4] ;
  wire \pin_reg[0][4]_0 ;
  wire \pin_reg[0][5] ;
  wire \pin_reg[0][5]_0 ;
  wire \pin_reg[0][6] ;
  wire \pin_reg[0][6]_0 ;
  wire \pin_reg[0][6]_1 ;
  wire \pin_reg[0][6]_2 ;
  wire \pin_reg[0][7] ;
  wire \pin_reg[0][7]_0 ;
  wire [3:0]\pin_reg[0][7]_1 ;
  wire [0:0]\pin_reg[0][7]_2 ;
  wire [2:0]\NLW_acc_out_reg[3]_i_6_CO_UNCONNECTED ;
  wire [2:0]\NLW_acc_out_reg[7]_i_9_CO_UNCONNECTED ;
  wire [3:1]NLW_carry_flag_reg_i_3_CO_UNCONNECTED;
  wire [3:0]NLW_carry_flag_reg_i_3_O_UNCONNECTED;

  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[1]_i_2 
       (.I0(Q[1]),
        .I1(pin[1]),
        .O(\pin_reg[0][1] ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[2]_i_2 
       (.I0(Q[2]),
        .I1(pin[2]),
        .O(\pin_reg[0][2]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \acc_out[2]_i_5 
       (.I0(Q[1]),
        .I1(Q[0]),
        .O(\pin_reg[0][2] ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[3]_i_10 
       (.I0(Q[2]),
        .I1(pin[2]),
        .O(\acc_out[3]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[3]_i_11 
       (.I0(Q[1]),
        .I1(pin[1]),
        .O(\acc_out[3]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[3]_i_12 
       (.I0(Q[0]),
        .I1(pin[0]),
        .O(\acc_out[3]_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \acc_out[3]_i_7 
       (.I0(Q[2]),
        .I1(Q[0]),
        .I2(Q[1]),
        .O(\pin_reg[0][3]_1 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[3]_i_9 
       (.I0(Q[3]),
        .I1(pin[3]),
        .O(\acc_out[3]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[4]_i_2 
       (.I0(Q[4]),
        .I1(pin[4]),
        .O(\pin_reg[0][4]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \acc_out[4]_i_5 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .O(\pin_reg[0][4] ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[5]_i_2 
       (.I0(Q[5]),
        .I1(pin[5]),
        .O(\pin_reg[0][5]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \acc_out[5]_i_5 
       (.I0(Q[4]),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[3]),
        .O(\pin_reg[0][5] ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[6]_i_2 
       (.I0(Q[6]),
        .I1(pin[6]),
        .O(\pin_reg[0][6]_2 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \acc_out[7]_i_10 
       (.I0(Q[6]),
        .I1(carry_flag_reg),
        .O(\pin_reg[0][7]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[7]_i_13 
       (.I0(Q[7]),
        .I1(pin[7]),
        .O(\acc_out[7]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[7]_i_14 
       (.I0(Q[6]),
        .I1(pin[6]),
        .O(\acc_out[7]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[7]_i_15 
       (.I0(Q[5]),
        .I1(pin[5]),
        .O(\acc_out[7]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[7]_i_16 
       (.I0(Q[4]),
        .I1(pin[4]),
        .O(\acc_out[7]_i_16_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[0]),
        .Q(Q[0]));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[1]),
        .Q(Q[1]));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[2]),
        .Q(Q[2]));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[3]),
        .Q(Q[3]));
  CARRY4 \acc_out_reg[3]_i_6 
       (.CI(1'b0),
        .CO({\acc_out_reg[3]_i_6_n_0 ,\NLW_acc_out_reg[3]_i_6_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(Q[3:0]),
        .O(O),
        .S({\acc_out[3]_i_9_n_0 ,\acc_out[3]_i_10_n_0 ,\acc_out[3]_i_11_n_0 ,\acc_out[3]_i_12_n_0 }));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[4]),
        .Q(Q[4]));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[5]),
        .Q(Q[5]));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[6]),
        .Q(Q[6]));
  FDCE #(
    .INIT(1'b0)) 
    \acc_out_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D[7]),
        .Q(Q[7]));
  CARRY4 \acc_out_reg[7]_i_9 
       (.CI(\acc_out_reg[3]_i_6_n_0 ),
        .CO({\acc_out_reg[7]_i_9_n_0 ,\NLW_acc_out_reg[7]_i_9_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(Q[7:4]),
        .O(\pin_reg[0][7]_1 ),
        .S({\acc_out[7]_i_13_n_0 ,\acc_out[7]_i_14_n_0 ,\acc_out[7]_i_15_n_0 ,\acc_out[7]_i_16_n_0 }));
  LUT6 #(
    .INIT(64'hA808080808080808)) 
    carry_flag_i_1
       (.I0(\ir_out_reg[4] ),
        .I1(carry_flag_reg_i_3_n_3),
        .I2(alu_opcode),
        .I3(Q[7]),
        .I4(carry_flag_reg),
        .I5(Q[6]),
        .O(alu_carry));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    carry_flag_i_5
       (.I0(Q[5]),
        .I1(Q[3]),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(carry_flag_reg));
  CARRY4 carry_flag_reg_i_3
       (.CI(\acc_out_reg[7]_i_9_n_0 ),
        .CO({NLW_carry_flag_reg_i_3_CO_UNCONNECTED[3:1],carry_flag_reg_i_3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_carry_flag_reg_i_3_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h7)) 
    i___0_carry__0_i_10__0
       (.I0(Q[3]),
        .I1(pin[2]),
        .O(\pin_reg[0][6]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h7)) 
    i___0_carry__0_i_11__0
       (.I0(Q[2]),
        .I1(pin[2]),
        .O(\pin_reg[0][6] ));
  LUT5 #(
    .INIT(32'hA5A5B44B)) 
    i___0_carry__0_i_7
       (.I0(Q[3]),
        .I1(pin[3]),
        .I2(Q[4]),
        .I3(pin[4]),
        .I4(alu_opcode),
        .O(\pin_reg[0][7]_2 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h7)) 
    i___0_carry__0_i_8__0
       (.I0(Q[4]),
        .I1(pin[2]),
        .O(\pin_reg[0][6]_1 ));
  LUT2 #(
    .INIT(4'h8)) 
    i___0_carry_i_3__0
       (.I0(Q[1]),
        .I1(pin[0]),
        .O(\pin_reg[0][3] ));
  LUT6 #(
    .INIT(64'h99C3993369C39933)) 
    i___0_carry_i_4__0
       (.I0(Q[2]),
        .I1(i___0_carry_i_8_n_0),
        .I2(Q[1]),
        .I3(pin[1]),
        .I4(pin[2]),
        .I5(Q[0]),
        .O(\pin_reg[0][3]_0 [1]));
  LUT5 #(
    .INIT(32'hA5B4A54B)) 
    i___0_carry_i_5
       (.I0(Q[2]),
        .I1(pin[2]),
        .I2(Q[3]),
        .I3(alu_opcode),
        .I4(pin[3]),
        .O(\pin_reg[0][3]_2 [1]));
  LUT5 #(
    .INIT(32'h0FB40F4B)) 
    i___0_carry_i_6
       (.I0(Q[1]),
        .I1(pin[1]),
        .I2(Q[2]),
        .I3(alu_opcode),
        .I4(pin[2]),
        .O(\pin_reg[0][3]_2 [0]));
  LUT2 #(
    .INIT(4'h8)) 
    i___0_carry_i_7
       (.I0(Q[0]),
        .I1(pin[0]),
        .O(\pin_reg[0][3]_0 [0]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h7)) 
    i___0_carry_i_8
       (.I0(Q[3]),
        .I1(pin[0]),
        .O(i___0_carry_i_8_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h7)) 
    i___22_carry__0_i_2
       (.I0(Q[1]),
        .I1(pin[5]),
        .O(\pin_reg[0][7] ));
  LUT2 #(
    .INIT(4'h8)) 
    i___22_carry_i_3
       (.I0(Q[1]),
        .I1(pin[3]),
        .O(DI));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    i___22_carry_i_5
       (.I0(Q[0]),
        .I1(pin[5]),
        .I2(Q[1]),
        .I3(pin[4]),
        .I4(pin[3]),
        .I5(Q[2]),
        .O(S[1]));
  LUT2 #(
    .INIT(4'h8)) 
    i___22_carry_i_7
       (.I0(Q[0]),
        .I1(pin[3]),
        .O(S[0]));
endmodule

module alu
   (data2,
    O,
    \pin_reg[0][7] ,
    \pin_reg[0][6] ,
    \pin_reg[0][7]_0 ,
    \pin_reg[0][6]_0 ,
    \pin_reg[0][7]_1 ,
    \pin_reg[0][6]_1 ,
    \pin_reg[0][4] ,
    \pin_reg[0][5] ,
    \pin_reg[0][4]_0 ,
    \pin_reg[0][4]_1 ,
    \pin_reg[0][4]_2 ,
    \pin_reg[0][3] ,
    DI,
    S,
    \acc_out_reg[5] ,
    \acc_out_reg[6] ,
    \acc_out_reg[3] ,
    \acc_out_reg[2] ,
    \acc_out_reg[5]_0 ,
    \acc_out_reg[5]_1 ,
    \acc_out_reg[3]_0 ,
    \acc_out_reg[1] ,
    \acc_out_reg[2]_0 ,
    \acc_out_reg[0] ,
    \acc_out_reg[0]_0 ,
    data4,
    \ir_out_reg[5] ,
    \acc_out_reg[7] ,
    \ir_out_reg[5]_0 ,
    \ir_out_reg[5]_1 ,
    \ir_out_reg[5]_2 ,
    \ir_out_reg[5]_3 ,
    \acc_out_reg[1]_0 ,
    \ir_out_reg[5]_4 ,
    \acc_out_reg[1]_1 ,
    \ir_out_reg[5]_5 ,
    \acc_out_reg[1]_2 ,
    alu_opcode,
    Q,
    pin,
    CO,
    \acc_out_reg[5]_2 );
  output [7:0]data2;
  output [3:0]O;
  output [1:0]\pin_reg[0][7] ;
  output [1:0]\pin_reg[0][6] ;
  output [0:0]\pin_reg[0][7]_0 ;
  output [0:0]\pin_reg[0][6]_0 ;
  output [0:0]\pin_reg[0][7]_1 ;
  output [3:0]\pin_reg[0][6]_1 ;
  output \pin_reg[0][4] ;
  output \pin_reg[0][5] ;
  output [3:0]\pin_reg[0][4]_0 ;
  output [1:0]\pin_reg[0][4]_1 ;
  output [0:0]\pin_reg[0][4]_2 ;
  output [0:0]\pin_reg[0][3] ;
  input [3:0]DI;
  input [3:0]S;
  input [2:0]\acc_out_reg[5] ;
  input [3:0]\acc_out_reg[6] ;
  input [2:0]\acc_out_reg[3] ;
  input [3:0]\acc_out_reg[2] ;
  input [2:0]\acc_out_reg[5]_0 ;
  input [3:0]\acc_out_reg[5]_1 ;
  input [2:0]\acc_out_reg[3]_0 ;
  input [3:0]\acc_out_reg[1] ;
  input [0:0]\acc_out_reg[2]_0 ;
  input [0:0]\acc_out_reg[0] ;
  input [0:0]\acc_out_reg[0]_0 ;
  input [1:0]data4;
  input [3:0]\ir_out_reg[5] ;
  input [3:0]\acc_out_reg[7] ;
  input [3:0]\ir_out_reg[5]_0 ;
  input [3:0]\ir_out_reg[5]_1 ;
  input [0:0]\ir_out_reg[5]_2 ;
  input [0:0]\ir_out_reg[5]_3 ;
  input [3:0]\acc_out_reg[1]_0 ;
  input [3:0]\ir_out_reg[5]_4 ;
  input [3:0]\acc_out_reg[1]_1 ;
  input [3:0]\ir_out_reg[5]_5 ;
  input [0:0]\acc_out_reg[1]_2 ;
  input [1:0]alu_opcode;
  input [1:0]Q;
  input [7:0]pin;
  input [0:0]CO;
  input [0:0]\acc_out_reg[5]_2 ;

  wire [0:0]CO;
  wire [3:0]DI;
  wire [3:0]O;
  wire [1:0]Q;
  wire [3:0]S;
  wire \_inferred__1/i___0_carry_n_0 ;
  wire \acc_out[4]_i_9_n_0 ;
  wire \acc_out[5]_i_11_n_0 ;
  wire \acc_out[5]_i_12_n_0 ;
  wire \acc_out[5]_i_13_n_0 ;
  wire \acc_out[5]_i_14_n_0 ;
  wire \acc_out[5]_i_15_n_0 ;
  wire \acc_out[5]_i_16_n_0 ;
  wire \acc_out[5]_i_17_n_0 ;
  wire \acc_out[5]_i_8_n_0 ;
  wire \acc_out[5]_i_9_n_0 ;
  wire [0:0]\acc_out_reg[0] ;
  wire [0:0]\acc_out_reg[0]_0 ;
  wire [3:0]\acc_out_reg[1] ;
  wire [3:0]\acc_out_reg[1]_0 ;
  wire [3:0]\acc_out_reg[1]_1 ;
  wire [0:0]\acc_out_reg[1]_2 ;
  wire [3:0]\acc_out_reg[2] ;
  wire [0:0]\acc_out_reg[2]_0 ;
  wire [2:0]\acc_out_reg[3] ;
  wire [2:0]\acc_out_reg[3]_0 ;
  wire [2:0]\acc_out_reg[5] ;
  wire [2:0]\acc_out_reg[5]_0 ;
  wire [3:0]\acc_out_reg[5]_1 ;
  wire [0:0]\acc_out_reg[5]_2 ;
  wire \acc_out_reg[5]_i_10_n_0 ;
  wire \acc_out_reg[5]_i_7_n_0 ;
  wire \acc_out_reg[5]_i_7_n_4 ;
  wire [3:0]\acc_out_reg[6] ;
  wire [3:0]\acc_out_reg[7] ;
  wire [1:0]alu_opcode;
  wire [7:0]data2;
  wire [1:0]data4;
  wire i___35_carry_i_1_n_0;
  wire i___35_carry_i_3_n_0;
  wire i___35_carry_i_4_n_0;
  wire i___35_carry_i_5_n_0;
  wire [3:0]\ir_out_reg[5] ;
  wire [3:0]\ir_out_reg[5]_0 ;
  wire [3:0]\ir_out_reg[5]_1 ;
  wire [0:0]\ir_out_reg[5]_2 ;
  wire [0:0]\ir_out_reg[5]_3 ;
  wire [3:0]\ir_out_reg[5]_4 ;
  wire [3:0]\ir_out_reg[5]_5 ;
  wire [7:0]pin;
  wire [0:0]\pin_reg[0][3] ;
  wire \pin_reg[0][4] ;
  wire [3:0]\pin_reg[0][4]_0 ;
  wire [1:0]\pin_reg[0][4]_1 ;
  wire [0:0]\pin_reg[0][4]_2 ;
  wire \pin_reg[0][5] ;
  wire [1:0]\pin_reg[0][6] ;
  wire [0:0]\pin_reg[0][6]_0 ;
  wire [3:0]\pin_reg[0][6]_1 ;
  wire [1:0]\pin_reg[0][7] ;
  wire [0:0]\pin_reg[0][7]_0 ;
  wire [0:0]\pin_reg[0][7]_1 ;
  wire \result0_inferred__0/i___0_carry__0_n_6 ;
  wire \result0_inferred__0/i___0_carry__0_n_7 ;
  wire \result0_inferred__0/i___0_carry_n_0 ;
  wire \result0_inferred__0/i___22_carry_n_0 ;
  wire \result0_inferred__0/i___22_carry_n_5 ;
  wire \result0_inferred__0/i___22_carry_n_6 ;
  wire \result0_inferred__0/i___35_carry_n_0 ;
  wire \result0_inferred__0/i___35_carry_n_5 ;
  wire \result0_inferred__0/i___35_carry_n_6 ;
  wire \result0_inferred__1/i___211_carry__0_n_0 ;
  wire \result0_inferred__1/i___211_carry_n_0 ;
  wire \result0_inferred__1/i___7_carry__0_n_0 ;
  wire \result0_inferred__1/i___7_carry__0_n_4 ;
  wire \result0_inferred__1/i___7_carry__0_n_5 ;
  wire \result0_inferred__1/i___7_carry__0_n_6 ;
  wire \result0_inferred__1/i___7_carry__0_n_7 ;
  wire \result0_inferred__1/i___7_carry_n_0 ;
  wire \result0_inferred__1/i___7_carry_n_4 ;
  wire \result0_inferred__1/i___7_carry_n_5 ;
  wire \result0_inferred__1/i___7_carry_n_6 ;
  wire \result0_inferred__1/i___7_carry_n_7 ;
  wire [2:0]\NLW__inferred__1/i___0_carry_CO_UNCONNECTED ;
  wire [3:0]\NLW__inferred__1/i___0_carry__0_CO_UNCONNECTED ;
  wire [3:0]\NLW_acc_out_reg[4]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_acc_out_reg[4]_i_6_O_UNCONNECTED ;
  wire [2:0]\NLW_acc_out_reg[5]_i_10_CO_UNCONNECTED ;
  wire [0:0]\NLW_acc_out_reg[5]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_acc_out_reg[5]_i_6_CO_UNCONNECTED ;
  wire [3:1]\NLW_acc_out_reg[5]_i_6_O_UNCONNECTED ;
  wire [2:0]\NLW_acc_out_reg[5]_i_7_CO_UNCONNECTED ;
  wire [2:0]\NLW_result0_inferred__0/i___0_carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_result0_inferred__0/i___0_carry__0_CO_UNCONNECTED ;
  wire [2:0]\NLW_result0_inferred__0/i___22_carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_result0_inferred__0/i___22_carry__0_CO_UNCONNECTED ;
  wire [3:1]\NLW_result0_inferred__0/i___22_carry__0_O_UNCONNECTED ;
  wire [2:0]\NLW_result0_inferred__0/i___35_carry_CO_UNCONNECTED ;
  wire [0:0]\NLW_result0_inferred__0/i___35_carry_O_UNCONNECTED ;
  wire [3:0]\NLW_result0_inferred__0/i___35_carry__0_CO_UNCONNECTED ;
  wire [3:1]\NLW_result0_inferred__0/i___35_carry__0_O_UNCONNECTED ;
  wire [2:0]\NLW_result0_inferred__1/i___211_carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_result0_inferred__1/i___211_carry_O_UNCONNECTED ;
  wire [2:0]\NLW_result0_inferred__1/i___211_carry__0_CO_UNCONNECTED ;
  wire [3:0]\NLW_result0_inferred__1/i___211_carry__0_O_UNCONNECTED ;
  wire [3:1]\NLW_result0_inferred__1/i___211_carry__1_CO_UNCONNECTED ;
  wire [3:0]\NLW_result0_inferred__1/i___211_carry__1_O_UNCONNECTED ;
  wire [2:0]\NLW_result0_inferred__1/i___7_carry_CO_UNCONNECTED ;
  wire [2:0]\NLW_result0_inferred__1/i___7_carry__0_CO_UNCONNECTED ;
  wire [3:1]\NLW_result0_inferred__1/i___7_carry__1_CO_UNCONNECTED ;
  wire [3:0]\NLW_result0_inferred__1/i___7_carry__1_O_UNCONNECTED ;

  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \_inferred__1/i___0_carry 
       (.CI(1'b0),
        .CO({\_inferred__1/i___0_carry_n_0 ,\NLW__inferred__1/i___0_carry_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b1),
        .DI(DI),
        .O(data2[3:0]),
        .S(S));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \_inferred__1/i___0_carry__0 
       (.CI(\_inferred__1/i___0_carry_n_0 ),
        .CO(\NLW__inferred__1/i___0_carry__0_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,\acc_out_reg[5] }),
        .O(data2[7:4]),
        .S(\acc_out_reg[6] ));
  LUT6 #(
    .INIT(64'hFCFCFC0CFA0A0A0A)) 
    \acc_out[4]_i_4 
       (.I0(\result0_inferred__0/i___35_carry_n_6 ),
        .I1(\pin_reg[0][6]_1 [1]),
        .I2(alu_opcode[1]),
        .I3(Q[0]),
        .I4(pin[4]),
        .I5(alu_opcode[0]),
        .O(\pin_reg[0][4] ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[4]_i_9 
       (.I0(\pin_reg[0][6]_1 [2]),
        .I1(pin[7]),
        .I2(\acc_out_reg[5]_i_7_n_4 ),
        .O(\acc_out[4]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_11 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[6]),
        .I2(\result0_inferred__1/i___7_carry__0_n_6 ),
        .O(\acc_out[5]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_12 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[5]),
        .I2(\result0_inferred__1/i___7_carry__0_n_7 ),
        .O(\acc_out[5]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_13 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[4]),
        .I2(\result0_inferred__1/i___7_carry_n_4 ),
        .O(\acc_out[5]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_14 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[3]),
        .I2(\result0_inferred__1/i___7_carry_n_5 ),
        .O(\acc_out[5]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_15 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[2]),
        .I2(\result0_inferred__1/i___7_carry_n_6 ),
        .O(\acc_out[5]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_16 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[1]),
        .I2(\result0_inferred__1/i___7_carry_n_7 ),
        .O(\acc_out[5]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_17 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[0]),
        .I2(Q[1]),
        .O(\acc_out[5]_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFCFCFC0CFA0A0A0A)) 
    \acc_out[5]_i_4 
       (.I0(\result0_inferred__0/i___35_carry_n_5 ),
        .I1(\pin_reg[0][6]_1 [2]),
        .I2(alu_opcode[1]),
        .I3(Q[1]),
        .I4(pin[5]),
        .I5(alu_opcode[0]),
        .O(\pin_reg[0][5] ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[5]_i_8 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(\result0_inferred__1/i___7_carry__0_n_4 ),
        .O(\acc_out[5]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[5]_i_9 
       (.I0(\pin_reg[0][6]_1 [3]),
        .I1(pin[7]),
        .I2(\result0_inferred__1/i___7_carry__0_n_5 ),
        .O(\acc_out[5]_i_9_n_0 ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \acc_out_reg[4]_i_6 
       (.CI(CO),
        .CO({\NLW_acc_out_reg[4]_i_6_CO_UNCONNECTED [3:2],\pin_reg[0][6]_1 [1],\NLW_acc_out_reg[4]_i_6_CO_UNCONNECTED [0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\pin_reg[0][6]_1 [2],\acc_out_reg[5]_i_7_n_4 }),
        .O({\NLW_acc_out_reg[4]_i_6_O_UNCONNECTED [3:1],\pin_reg[0][3] }),
        .S({1'b0,1'b0,\acc_out_reg[5]_2 ,\acc_out[4]_i_9_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \acc_out_reg[5]_i_10 
       (.CI(1'b0),
        .CO({\acc_out_reg[5]_i_10_n_0 ,\NLW_acc_out_reg[5]_i_10_CO_UNCONNECTED [2:0]}),
        .CYINIT(\pin_reg[0][6]_1 [3]),
        .DI({\result0_inferred__1/i___7_carry_n_6 ,\result0_inferred__1/i___7_carry_n_7 ,Q[1],1'b0}),
        .O({\pin_reg[0][4]_0 [0],\pin_reg[0][4]_1 ,\NLW_acc_out_reg[5]_i_10_O_UNCONNECTED [0]}),
        .S({\acc_out[5]_i_15_n_0 ,\acc_out[5]_i_16_n_0 ,\acc_out[5]_i_17_n_0 ,1'b1}));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \acc_out_reg[5]_i_6 
       (.CI(\acc_out_reg[5]_i_7_n_0 ),
        .CO({\NLW_acc_out_reg[5]_i_6_CO_UNCONNECTED [3:2],\pin_reg[0][6]_1 [2],\NLW_acc_out_reg[5]_i_6_CO_UNCONNECTED [0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\pin_reg[0][6]_1 [3],\result0_inferred__1/i___7_carry__0_n_5 }),
        .O({\NLW_acc_out_reg[5]_i_6_O_UNCONNECTED [3:1],\pin_reg[0][4]_2 }),
        .S({1'b0,1'b0,\acc_out[5]_i_8_n_0 ,\acc_out[5]_i_9_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \acc_out_reg[5]_i_7 
       (.CI(\acc_out_reg[5]_i_10_n_0 ),
        .CO({\acc_out_reg[5]_i_7_n_0 ,\NLW_acc_out_reg[5]_i_7_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\result0_inferred__1/i___7_carry__0_n_6 ,\result0_inferred__1/i___7_carry__0_n_7 ,\result0_inferred__1/i___7_carry_n_4 ,\result0_inferred__1/i___7_carry_n_5 }),
        .O({\acc_out_reg[5]_i_7_n_4 ,\pin_reg[0][4]_0 [3:1]}),
        .S({\acc_out[5]_i_11_n_0 ,\acc_out[5]_i_12_n_0 ,\acc_out[5]_i_13_n_0 ,\acc_out[5]_i_14_n_0 }));
  LUT2 #(
    .INIT(4'h6)) 
    i___35_carry_i_1
       (.I0(\pin_reg[0][7] [0]),
        .I1(\pin_reg[0][6] [1]),
        .O(i___35_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___35_carry_i_3
       (.I0(\result0_inferred__0/i___0_carry__0_n_6 ),
        .I1(\result0_inferred__0/i___22_carry_n_5 ),
        .O(i___35_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___35_carry_i_4
       (.I0(\result0_inferred__0/i___0_carry__0_n_7 ),
        .I1(\result0_inferred__0/i___22_carry_n_6 ),
        .O(i___35_carry_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___35_carry_i_5
       (.I0(O[3]),
        .I1(\pin_reg[0][6] [0]),
        .O(i___35_carry_i_5_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__0/i___0_carry 
       (.CI(1'b0),
        .CO({\result0_inferred__0/i___0_carry_n_0 ,\NLW_result0_inferred__0/i___0_carry_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\acc_out_reg[3] ,1'b0}),
        .O(O),
        .S(\acc_out_reg[2] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__0/i___0_carry__0 
       (.CI(\result0_inferred__0/i___0_carry_n_0 ),
        .CO(\NLW_result0_inferred__0/i___0_carry__0_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,\acc_out_reg[5]_0 }),
        .O({\pin_reg[0][7] ,\result0_inferred__0/i___0_carry__0_n_6 ,\result0_inferred__0/i___0_carry__0_n_7 }),
        .S(\acc_out_reg[5]_1 ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__0/i___22_carry 
       (.CI(1'b0),
        .CO({\result0_inferred__0/i___22_carry_n_0 ,\NLW_result0_inferred__0/i___22_carry_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({\acc_out_reg[3]_0 ,1'b0}),
        .O({\pin_reg[0][6] [1],\result0_inferred__0/i___22_carry_n_5 ,\result0_inferred__0/i___22_carry_n_6 ,\pin_reg[0][6] [0]}),
        .S(\acc_out_reg[1] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__0/i___22_carry__0 
       (.CI(\result0_inferred__0/i___22_carry_n_0 ),
        .CO(\NLW_result0_inferred__0/i___22_carry__0_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_result0_inferred__0/i___22_carry__0_O_UNCONNECTED [3:1],\pin_reg[0][7]_0 }),
        .S({1'b0,1'b0,1'b0,\acc_out_reg[2]_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__0/i___35_carry 
       (.CI(1'b0),
        .CO({\result0_inferred__0/i___35_carry_n_0 ,\NLW_result0_inferred__0/i___35_carry_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({i___35_carry_i_1_n_0,\result0_inferred__0/i___0_carry__0_n_6 ,\result0_inferred__0/i___0_carry__0_n_7 ,O[3]}),
        .O({\pin_reg[0][6]_0 ,\result0_inferred__0/i___35_carry_n_5 ,\result0_inferred__0/i___35_carry_n_6 ,\NLW_result0_inferred__0/i___35_carry_O_UNCONNECTED [0]}),
        .S({\acc_out_reg[0] ,i___35_carry_i_3_n_0,i___35_carry_i_4_n_0,i___35_carry_i_5_n_0}));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__0/i___35_carry__0 
       (.CI(\result0_inferred__0/i___35_carry_n_0 ),
        .CO(\NLW_result0_inferred__0/i___35_carry__0_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_result0_inferred__0/i___35_carry__0_O_UNCONNECTED [3:1],\pin_reg[0][7]_1 }),
        .S({1'b0,1'b0,1'b0,\acc_out_reg[0]_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__1/i___211_carry 
       (.CI(1'b0),
        .CO({\result0_inferred__1/i___211_carry_n_0 ,\NLW_result0_inferred__1/i___211_carry_CO_UNCONNECTED [2:0]}),
        .CYINIT(data4[0]),
        .DI(\acc_out_reg[1]_0 ),
        .O(\NLW_result0_inferred__1/i___211_carry_O_UNCONNECTED [3:0]),
        .S(\ir_out_reg[5]_4 ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__1/i___211_carry__0 
       (.CI(\result0_inferred__1/i___211_carry_n_0 ),
        .CO({\result0_inferred__1/i___211_carry__0_n_0 ,\NLW_result0_inferred__1/i___211_carry__0_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(\acc_out_reg[1]_1 ),
        .O(\NLW_result0_inferred__1/i___211_carry__0_O_UNCONNECTED [3:0]),
        .S(\ir_out_reg[5]_5 ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__1/i___211_carry__1 
       (.CI(\result0_inferred__1/i___211_carry__0_n_0 ),
        .CO({\NLW_result0_inferred__1/i___211_carry__1_CO_UNCONNECTED [3:1],\pin_reg[0][6]_1 [0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,data4[0]}),
        .O(\NLW_result0_inferred__1/i___211_carry__1_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\acc_out_reg[1]_2 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__1/i___7_carry 
       (.CI(1'b0),
        .CO({\result0_inferred__1/i___7_carry_n_0 ,\NLW_result0_inferred__1/i___7_carry_CO_UNCONNECTED [2:0]}),
        .CYINIT(data4[1]),
        .DI(\ir_out_reg[5] ),
        .O({\result0_inferred__1/i___7_carry_n_4 ,\result0_inferred__1/i___7_carry_n_5 ,\result0_inferred__1/i___7_carry_n_6 ,\result0_inferred__1/i___7_carry_n_7 }),
        .S(\acc_out_reg[7] ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__1/i___7_carry__0 
       (.CI(\result0_inferred__1/i___7_carry_n_0 ),
        .CO({\result0_inferred__1/i___7_carry__0_n_0 ,\NLW_result0_inferred__1/i___7_carry__0_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(\ir_out_reg[5]_0 ),
        .O({\result0_inferred__1/i___7_carry__0_n_4 ,\result0_inferred__1/i___7_carry__0_n_5 ,\result0_inferred__1/i___7_carry__0_n_6 ,\result0_inferred__1/i___7_carry__0_n_7 }),
        .S(\ir_out_reg[5]_1 ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \result0_inferred__1/i___7_carry__1 
       (.CI(\result0_inferred__1/i___7_carry__0_n_0 ),
        .CO({\NLW_result0_inferred__1/i___7_carry__1_CO_UNCONNECTED [3:1],\pin_reg[0][6]_1 [3]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\ir_out_reg[5]_2 }),
        .O(\NLW_result0_inferred__1/i___7_carry__1_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\ir_out_reg[5]_3 }));
endmodule

module control_unit
   (\pc_out_reg[0] ,
    Q,
    D,
    clk_IBUF_BUFG,
    AR);
  output \pc_out_reg[0] ;
  output [1:0]Q;
  output [0:0]D;
  input clk_IBUF_BUFG;
  input [0:0]AR;

  wire [0:0]AR;
  wire [0:0]D;
  wire [1:0]Q;
  wire clk_IBUF_BUFG;
  wire \pc_out_reg[0] ;
  wire \state[1]_i_1_n_0 ;

  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \ir_out[7]_i_1 
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(D));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \pin[0][7]_i_3 
       (.I0(Q[1]),
        .I1(Q[0]),
        .O(\pc_out_reg[0] ));
  LUT2 #(
    .INIT(4'h2)) 
    \state[1]_i_1 
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(\state[1]_i_1_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \state_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(AR),
        .D(D),
        .Q(Q[0]));
  FDCE #(
    .INIT(1'b0)) 
    \state_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(AR),
        .D(\state[1]_i_1_n_0 ),
        .Q(Q[1]));
endmodule

module flags_register
   (cf,
    zf,
    \pc_out_reg[7] ,
    E,
    alu_carry,
    clk_IBUF_BUFG,
    AR,
    alu_zero,
    Q);
  output cf;
  output zf;
  output \pc_out_reg[7] ;
  input [0:0]E;
  input alu_carry;
  input clk_IBUF_BUFG;
  input [0:0]AR;
  input alu_zero;
  input [1:0]Q;

  wire [0:0]AR;
  wire [0:0]E;
  wire [1:0]Q;
  wire alu_carry;
  wire alu_zero;
  wire cf;
  wire clk_IBUF_BUFG;
  wire \pc_out_reg[7] ;
  wire zf;

  FDCE #(
    .INIT(1'b0)) 
    carry_flag_reg
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(alu_carry),
        .Q(cf));
  LUT4 #(
    .INIT(16'h0344)) 
    \pc_out[7]_i_4 
       (.I0(zf),
        .I1(Q[0]),
        .I2(cf),
        .I3(Q[1]),
        .O(\pc_out_reg[7] ));
  FDCE #(
    .INIT(1'b0)) 
    zero_flag_reg
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(alu_zero),
        .Q(zf));
endmodule

module instruction_memory
   (D,
    \pc_out_reg[0] ,
    clk_IBUF_BUFG,
    \pc_out_reg[7] ,
    \pc_out_reg[3] ,
    \pc_out_reg[1] ,
    \pc_out_reg[2] ,
    \pc_out_reg[3]_0 );
  output [7:0]D;
  input [3:0]\pc_out_reg[0] ;
  input clk_IBUF_BUFG;
  input \pc_out_reg[7] ;
  input \pc_out_reg[3] ;
  input \pc_out_reg[1] ;
  input \pc_out_reg[2] ;
  input \pc_out_reg[3]_0 ;

  wire [7:0]D;
  wire clk_IBUF_BUFG;
  wire [3:0]\pc_out_reg[0] ;
  wire \pc_out_reg[1] ;
  wire \pc_out_reg[2] ;
  wire \pc_out_reg[3] ;
  wire \pc_out_reg[3]_0 ;
  wire \pc_out_reg[7] ;

  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[3]_0 ),
        .Q(D[0]),
        .R(\pc_out_reg[7] ));
  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[2] ),
        .Q(D[1]),
        .R(\pc_out_reg[7] ));
  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[1] ),
        .Q(D[2]),
        .R(\pc_out_reg[7] ));
  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[0] [0]),
        .Q(D[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[0] [1]),
        .Q(D[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[0] [2]),
        .Q(D[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[3] ),
        .Q(D[6]),
        .R(\pc_out_reg[7] ));
  FDRE #(
    .INIT(1'b0)) 
    \instr_word_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pc_out_reg[0] [3]),
        .Q(D[7]),
        .R(1'b0));
endmodule

module instruction_register
   (alu_zero,
    D,
    \pin_reg[0][3] ,
    \pc_out_reg[0] ,
    \pc_out_reg[7] ,
    pc_load,
    E,
    \port_out_reg[7] ,
    \pin_reg[7][7] ,
    \pin_reg[6][7] ,
    \pin_reg[3][7] ,
    \pin_reg[2][7] ,
    \pin_reg[5][7] ,
    \pin_reg[4][7] ,
    \pin_reg[1][7] ,
    \pin_reg[0][7] ,
    carry_flag_reg,
    carry_flag_reg_0,
    \pin_reg[0][7]_0 ,
    \pin_reg[0][7]_1 ,
    DI,
    S,
    \ir_out_reg[7]_0 ,
    \ir_out_reg[5]_0 ,
    pin,
    Q,
    \acc_out_reg[6] ,
    \acc_out_reg[6]_0 ,
    \acc_out_reg[5] ,
    \acc_out_reg[5]_0 ,
    \acc_out_reg[4] ,
    \acc_out_reg[4]_0 ,
    \acc_out_reg[2] ,
    \acc_out_reg[2]_0 ,
    \acc_out_reg[1] ,
    \acc_out_reg[1]_0 ,
    \pc_out_reg[0]_0 ,
    \state_reg[1] ,
    zero_flag_reg,
    \state_reg[1]_0 ,
    zf,
    cf,
    data2,
    O,
    \acc_out_reg[0] ,
    \acc_out_reg[1]_1 ,
    \acc_out_reg[2]_1 ,
    \acc_out_reg[7] ,
    \acc_out_reg[3] ,
    \acc_out_reg[4]_1 ,
    \acc_out_reg[5]_1 ,
    \acc_out_reg[6]_1 ,
    \acc_out_reg[0]_0 ,
    \state_reg[0] ,
    \instr_word_reg[7] ,
    clk_IBUF_BUFG,
    AR);
  output alu_zero;
  output [7:0]D;
  output [1:0]\pin_reg[0][3] ;
  output [0:0]\pc_out_reg[0] ;
  output [6:0]\pc_out_reg[7] ;
  output pc_load;
  output [0:0]E;
  output [0:0]\port_out_reg[7] ;
  output [0:0]\pin_reg[7][7] ;
  output [0:0]\pin_reg[6][7] ;
  output [0:0]\pin_reg[3][7] ;
  output [0:0]\pin_reg[2][7] ;
  output [0:0]\pin_reg[5][7] ;
  output [0:0]\pin_reg[4][7] ;
  output [0:0]\pin_reg[1][7] ;
  output [0:0]\pin_reg[0][7] ;
  output carry_flag_reg;
  output [0:0]carry_flag_reg_0;
  output \pin_reg[0][7]_0 ;
  output [2:0]\pin_reg[0][7]_1 ;
  output [3:0]DI;
  output [0:0]S;
  input \ir_out_reg[7]_0 ;
  input \ir_out_reg[5]_0 ;
  input [6:0]pin;
  input [7:0]Q;
  input \acc_out_reg[6] ;
  input \acc_out_reg[6]_0 ;
  input \acc_out_reg[5] ;
  input \acc_out_reg[5]_0 ;
  input \acc_out_reg[4] ;
  input \acc_out_reg[4]_0 ;
  input \acc_out_reg[2] ;
  input \acc_out_reg[2]_0 ;
  input \acc_out_reg[1] ;
  input \acc_out_reg[1]_0 ;
  input [0:0]\pc_out_reg[0]_0 ;
  input [1:0]\state_reg[1] ;
  input zero_flag_reg;
  input \state_reg[1]_0 ;
  input zf;
  input cf;
  input [7:0]data2;
  input [3:0]O;
  input \acc_out_reg[0] ;
  input \acc_out_reg[1]_1 ;
  input \acc_out_reg[2]_1 ;
  input [3:0]\acc_out_reg[7] ;
  input \acc_out_reg[3] ;
  input \acc_out_reg[4]_1 ;
  input \acc_out_reg[5]_1 ;
  input \acc_out_reg[6]_1 ;
  input [0:0]\acc_out_reg[0]_0 ;
  input [0:0]\state_reg[0] ;
  input [7:0]\instr_word_reg[7] ;
  input clk_IBUF_BUFG;
  input [0:0]AR;

  wire [0:0]AR;
  wire [7:0]D;
  wire [3:0]DI;
  wire [0:0]E;
  wire [3:0]O;
  wire [7:0]Q;
  wire [0:0]S;
  wire \acc_out[0]_i_3_n_0 ;
  wire \acc_out[0]_i_4_n_0 ;
  wire \acc_out[1]_i_3_n_0 ;
  wire \acc_out[2]_i_3_n_0 ;
  wire \acc_out[3]_i_2_n_0 ;
  wire \acc_out[3]_i_3_n_0 ;
  wire \acc_out[3]_i_5_n_0 ;
  wire \acc_out[4]_i_3_n_0 ;
  wire \acc_out[5]_i_3_n_0 ;
  wire \acc_out[6]_i_3_n_0 ;
  wire \acc_out[6]_i_5_n_0 ;
  wire \acc_out[6]_i_6_n_0 ;
  wire \acc_out[7]_i_3_n_0 ;
  wire \acc_out[7]_i_5_n_0 ;
  wire \acc_out[7]_i_6_n_0 ;
  wire \acc_out[7]_i_8_n_0 ;
  wire \acc_out_reg[0] ;
  wire [0:0]\acc_out_reg[0]_0 ;
  wire \acc_out_reg[1] ;
  wire \acc_out_reg[1]_0 ;
  wire \acc_out_reg[1]_1 ;
  wire \acc_out_reg[2] ;
  wire \acc_out_reg[2]_0 ;
  wire \acc_out_reg[2]_1 ;
  wire \acc_out_reg[3] ;
  wire \acc_out_reg[4] ;
  wire \acc_out_reg[4]_0 ;
  wire \acc_out_reg[4]_1 ;
  wire \acc_out_reg[5] ;
  wire \acc_out_reg[5]_0 ;
  wire \acc_out_reg[5]_1 ;
  wire \acc_out_reg[6] ;
  wire \acc_out_reg[6]_0 ;
  wire \acc_out_reg[6]_1 ;
  wire [3:0]\acc_out_reg[7] ;
  wire [3:3]alu_opcode;
  wire alu_zero;
  wire carry_flag_reg;
  wire [0:0]carry_flag_reg_0;
  wire cf;
  wire clk_IBUF_BUFG;
  wire [7:0]data2;
  wire [7:0]\instr_word_reg[7] ;
  wire [0:0]ir_out;
  wire \ir_out_reg[5]_0 ;
  wire \ir_out_reg[7]_0 ;
  wire pc_load;
  wire \pc_out[7]_i_6_n_0 ;
  wire [0:0]\pc_out_reg[0] ;
  wire [0:0]\pc_out_reg[0]_0 ;
  wire [6:0]\pc_out_reg[7] ;
  wire [6:0]pin;
  wire \pin[0][7]_i_2_n_0 ;
  wire \pin[2][7]_i_2_n_0 ;
  wire [1:0]\pin_reg[0][3] ;
  wire [0:0]\pin_reg[0][7] ;
  wire \pin_reg[0][7]_0 ;
  wire [2:0]\pin_reg[0][7]_1 ;
  wire [0:0]\pin_reg[1][7] ;
  wire [0:0]\pin_reg[2][7] ;
  wire [0:0]\pin_reg[3][7] ;
  wire [0:0]\pin_reg[4][7] ;
  wire [0:0]\pin_reg[5][7] ;
  wire [0:0]\pin_reg[6][7] ;
  wire [0:0]\pin_reg[7][7] ;
  wire [0:0]\port_out_reg[7] ;
  wire [0:0]\state_reg[0] ;
  wire [1:0]\state_reg[1] ;
  wire \state_reg[1]_0 ;
  wire zero_flag_i_2_n_0;
  wire zero_flag_reg;
  wire zf;

  LUT5 #(
    .INIT(32'h60FF6060)) 
    \acc_out[0]_i_1 
       (.I0(Q[0]),
        .I1(pin[0]),
        .I2(\acc_out[0]_i_3_n_0 ),
        .I3(alu_opcode),
        .I4(\acc_out[0]_i_4_n_0 ),
        .O(D[0]));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \acc_out[0]_i_3 
       (.I0(\state_reg[1] [1]),
        .I1(\state_reg[1] [0]),
        .I2(\pc_out_reg[7] [4]),
        .I3(\pc_out_reg[7] [3]),
        .I4(\pc_out_reg[7] [5]),
        .I5(\pc_out_reg[7] [6]),
        .O(\acc_out[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFF005555CCCCF0F0)) 
    \acc_out[0]_i_4 
       (.I0(Q[0]),
        .I1(data2[0]),
        .I2(O[0]),
        .I3(\acc_out_reg[0] ),
        .I4(\acc_out[6]_i_5_n_0 ),
        .I5(\acc_out[6]_i_6_n_0 ),
        .O(\acc_out[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h333030303030B8B8)) 
    \acc_out[1]_i_1 
       (.I0(\acc_out_reg[1] ),
        .I1(alu_opcode),
        .I2(\acc_out[1]_i_3_n_0 ),
        .I3(\acc_out_reg[1]_0 ),
        .I4(\acc_out[6]_i_5_n_0 ),
        .I5(\acc_out[6]_i_6_n_0 ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'h00B833B833B800B8)) 
    \acc_out[1]_i_3 
       (.I0(data2[1]),
        .I1(\acc_out[6]_i_5_n_0 ),
        .I2(O[1]),
        .I3(\acc_out[6]_i_6_n_0 ),
        .I4(Q[1]),
        .I5(Q[0]),
        .O(\acc_out[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h333030303030B8B8)) 
    \acc_out[2]_i_1 
       (.I0(\acc_out_reg[2] ),
        .I1(alu_opcode),
        .I2(\acc_out[2]_i_3_n_0 ),
        .I3(\acc_out_reg[2]_0 ),
        .I4(\acc_out[6]_i_5_n_0 ),
        .I5(\acc_out[6]_i_6_n_0 ),
        .O(D[2]));
  LUT6 #(
    .INIT(64'h00B833B833B800B8)) 
    \acc_out[2]_i_3 
       (.I0(data2[2]),
        .I1(\acc_out[6]_i_5_n_0 ),
        .I2(O[2]),
        .I3(\acc_out[6]_i_6_n_0 ),
        .I4(Q[2]),
        .I5(\acc_out_reg[1]_1 ),
        .O(\acc_out[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBABABABABA)) 
    \acc_out[3]_i_1 
       (.I0(\acc_out[3]_i_2_n_0 ),
        .I1(alu_opcode),
        .I2(\acc_out[3]_i_3_n_0 ),
        .I3(\ir_out_reg[7]_0 ),
        .I4(\acc_out[3]_i_5_n_0 ),
        .I5(\acc_out[7]_i_8_n_0 ),
        .O(D[3]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \acc_out[3]_i_2 
       (.I0(\acc_out[0]_i_3_n_0 ),
        .I1(pin[3]),
        .I2(Q[3]),
        .O(\acc_out[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00B833B833B800B8)) 
    \acc_out[3]_i_3 
       (.I0(data2[3]),
        .I1(\acc_out[6]_i_5_n_0 ),
        .I2(O[3]),
        .I3(\acc_out[6]_i_6_n_0 ),
        .I4(Q[3]),
        .I5(\acc_out_reg[2]_1 ),
        .O(\acc_out[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'hE800)) 
    \acc_out[3]_i_5 
       (.I0(\pin_reg[0][3] [0]),
        .I1(Q[3]),
        .I2(pin[3]),
        .I3(\pin_reg[0][3] [1]),
        .O(\acc_out[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h333030303030B8B8)) 
    \acc_out[4]_i_1 
       (.I0(\acc_out_reg[4] ),
        .I1(alu_opcode),
        .I2(\acc_out[4]_i_3_n_0 ),
        .I3(\acc_out_reg[4]_0 ),
        .I4(\acc_out[6]_i_5_n_0 ),
        .I5(\acc_out[6]_i_6_n_0 ),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h00B833B833B800B8)) 
    \acc_out[4]_i_3 
       (.I0(data2[4]),
        .I1(\acc_out[6]_i_5_n_0 ),
        .I2(\acc_out_reg[7] [0]),
        .I3(\acc_out[6]_i_6_n_0 ),
        .I4(Q[4]),
        .I5(\acc_out_reg[3] ),
        .O(\acc_out[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h333030303030B8B8)) 
    \acc_out[5]_i_1 
       (.I0(\acc_out_reg[5] ),
        .I1(alu_opcode),
        .I2(\acc_out[5]_i_3_n_0 ),
        .I3(\acc_out_reg[5]_0 ),
        .I4(\acc_out[6]_i_5_n_0 ),
        .I5(\acc_out[6]_i_6_n_0 ),
        .O(D[5]));
  LUT6 #(
    .INIT(64'h00B833B833B800B8)) 
    \acc_out[5]_i_3 
       (.I0(data2[5]),
        .I1(\acc_out[6]_i_5_n_0 ),
        .I2(\acc_out_reg[7] [1]),
        .I3(\acc_out[6]_i_6_n_0 ),
        .I4(Q[5]),
        .I5(\acc_out_reg[4]_1 ),
        .O(\acc_out[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h333030303030B8B8)) 
    \acc_out[6]_i_1 
       (.I0(\acc_out_reg[6] ),
        .I1(alu_opcode),
        .I2(\acc_out[6]_i_3_n_0 ),
        .I3(\acc_out_reg[6]_0 ),
        .I4(\acc_out[6]_i_5_n_0 ),
        .I5(\acc_out[6]_i_6_n_0 ),
        .O(D[6]));
  LUT6 #(
    .INIT(64'h00B833B833B800B8)) 
    \acc_out[6]_i_3 
       (.I0(data2[6]),
        .I1(\acc_out[6]_i_5_n_0 ),
        .I2(\acc_out_reg[7] [2]),
        .I3(\acc_out[6]_i_6_n_0 ),
        .I4(Q[6]),
        .I5(\acc_out_reg[5]_1 ),
        .O(\acc_out[6]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h00000E00)) 
    \acc_out[6]_i_5 
       (.I0(\pc_out_reg[7] [4]),
        .I1(\pc_out_reg[7] [5]),
        .I2(\state_reg[1] [0]),
        .I3(\state_reg[1] [1]),
        .I4(\pc_out_reg[7] [6]),
        .O(\acc_out[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F40000)) 
    \acc_out[6]_i_6 
       (.I0(\pc_out_reg[7] [4]),
        .I1(\pc_out_reg[7] [3]),
        .I2(\pc_out_reg[7] [5]),
        .I3(\state_reg[1] [0]),
        .I4(\state_reg[1] [1]),
        .I5(\pc_out_reg[7] [6]),
        .O(\acc_out[6]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h00001F00)) 
    \acc_out[7]_i_1 
       (.I0(\pc_out_reg[7] [4]),
        .I1(\pc_out_reg[7] [5]),
        .I2(\pc_out_reg[7] [6]),
        .I3(\state_reg[1] [1]),
        .I4(\state_reg[1] [0]),
        .O(carry_flag_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \acc_out[7]_i_11 
       (.I0(\pc_out_reg[7] [6]),
        .I1(\state_reg[1] [1]),
        .I2(\state_reg[1] [0]),
        .I3(\pc_out_reg[7] [4]),
        .O(\pin_reg[0][3] [1]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h00000200)) 
    \acc_out[7]_i_12 
       (.I0(\pc_out_reg[7] [3]),
        .I1(\pc_out_reg[7] [4]),
        .I2(\state_reg[1] [0]),
        .I3(\state_reg[1] [1]),
        .I4(\pc_out_reg[7] [6]),
        .O(\pin_reg[0][7]_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBBABABABABA)) 
    \acc_out[7]_i_2 
       (.I0(\acc_out[7]_i_3_n_0 ),
        .I1(alu_opcode),
        .I2(\acc_out[7]_i_5_n_0 ),
        .I3(\acc_out[7]_i_6_n_0 ),
        .I4(\ir_out_reg[5]_0 ),
        .I5(\acc_out[7]_i_8_n_0 ),
        .O(D[7]));
  LUT3 #(
    .INIT(8'h28)) 
    \acc_out[7]_i_3 
       (.I0(\acc_out[0]_i_3_n_0 ),
        .I1(pin[6]),
        .I2(Q[7]),
        .O(\acc_out[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \acc_out[7]_i_4 
       (.I0(\pc_out_reg[7] [6]),
        .I1(\pc_out_reg[7] [5]),
        .I2(\pc_out_reg[7] [3]),
        .I3(\pc_out_reg[7] [4]),
        .I4(\state_reg[1] [0]),
        .I5(\state_reg[1] [1]),
        .O(alu_opcode));
  LUT6 #(
    .INIT(64'h0033B8B83300B8B8)) 
    \acc_out[7]_i_5 
       (.I0(data2[7]),
        .I1(\acc_out[6]_i_5_n_0 ),
        .I2(\acc_out_reg[7] [3]),
        .I3(\acc_out_reg[6]_1 ),
        .I4(\acc_out[6]_i_6_n_0 ),
        .I5(Q[7]),
        .O(\acc_out[7]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hEE0088F0)) 
    \acc_out[7]_i_6 
       (.I0(Q[7]),
        .I1(pin[6]),
        .I2(\acc_out_reg[0]_0 ),
        .I3(\pin_reg[0][3] [1]),
        .I4(\pin_reg[0][3] [0]),
        .O(\acc_out[7]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \acc_out[7]_i_8 
       (.I0(\pc_out_reg[7] [6]),
        .I1(\state_reg[1] [1]),
        .I2(\state_reg[1] [0]),
        .I3(\pc_out_reg[7] [5]),
        .O(\acc_out[7]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFFFFFF03FFFF)) 
    carry_flag_i_2
       (.I0(\pc_out_reg[7] [3]),
        .I1(\pc_out_reg[7] [4]),
        .I2(\pc_out_reg[7] [5]),
        .I3(\state_reg[1] [0]),
        .I4(\state_reg[1] [1]),
        .I5(\pc_out_reg[7] [6]),
        .O(carry_flag_reg));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    carry_flag_i_4
       (.I0(\pc_out_reg[7] [6]),
        .I1(\state_reg[1] [1]),
        .I2(\state_reg[1] [0]),
        .I3(\pc_out_reg[7] [3]),
        .O(\pin_reg[0][3] [0]));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFEFFFFF)) 
    i___0_carry__0_i_1__0
       (.I0(Q[5]),
        .I1(\pc_out_reg[7] [6]),
        .I2(\state_reg[1] [1]),
        .I3(\state_reg[1] [0]),
        .I4(\pc_out_reg[7] [3]),
        .I5(pin[5]),
        .O(\pin_reg[0][7]_1 [2]));
  LUT6 #(
    .INIT(64'hAAAAAAAAFFEFFFFF)) 
    i___0_carry__0_i_2__0
       (.I0(Q[4]),
        .I1(\pc_out_reg[7] [6]),
        .I2(\state_reg[1] [1]),
        .I3(\state_reg[1] [0]),
        .I4(\pc_out_reg[7] [3]),
        .I5(pin[4]),
        .O(\pin_reg[0][7]_1 [1]));
  LUT6 #(
    .INIT(64'hFFFFFFFF55455555)) 
    i___0_carry__0_i_3
       (.I0(pin[3]),
        .I1(\pc_out_reg[7] [6]),
        .I2(\state_reg[1] [1]),
        .I3(\state_reg[1] [0]),
        .I4(\pc_out_reg[7] [3]),
        .I5(Q[3]),
        .O(\pin_reg[0][7]_1 [0]));
  LUT6 #(
    .INIT(64'hFFFFFFFF55455555)) 
    i___0_carry_i_1
       (.I0(pin[2]),
        .I1(\pc_out_reg[7] [6]),
        .I2(\state_reg[1] [1]),
        .I3(\state_reg[1] [0]),
        .I4(\pc_out_reg[7] [3]),
        .I5(Q[2]),
        .O(DI[3]));
  LUT6 #(
    .INIT(64'hFFDFFFDF0000FFDF)) 
    i___0_carry_i_2
       (.I0(\pc_out_reg[7] [3]),
        .I1(\state_reg[1] [0]),
        .I2(\state_reg[1] [1]),
        .I3(\pc_out_reg[7] [6]),
        .I4(pin[1]),
        .I5(Q[1]),
        .O(DI[2]));
  LUT6 #(
    .INIT(64'hBBBBBABBBBBBBBBB)) 
    i___0_carry_i_3
       (.I0(Q[0]),
        .I1(pin[0]),
        .I2(\pc_out_reg[7] [6]),
        .I3(\state_reg[1] [1]),
        .I4(\state_reg[1] [0]),
        .I5(\pc_out_reg[7] [3]),
        .O(DI[1]));
  LUT6 #(
    .INIT(64'h55555555AAAAA6AA)) 
    i___0_carry_i_4
       (.I0(Q[0]),
        .I1(\pc_out_reg[7] [3]),
        .I2(\state_reg[1] [0]),
        .I3(\state_reg[1] [1]),
        .I4(\pc_out_reg[7] [6]),
        .I5(pin[0]),
        .O(DI[0]));
  LUT6 #(
    .INIT(64'hAABAAAAA55455555)) 
    i___0_carry_i_8__0
       (.I0(pin[0]),
        .I1(\pc_out_reg[7] [6]),
        .I2(\state_reg[1] [1]),
        .I3(\state_reg[1] [0]),
        .I4(\pc_out_reg[7] [3]),
        .I5(Q[0]),
        .O(S));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [0]),
        .Q(ir_out));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [1]),
        .Q(\pc_out_reg[7] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [2]),
        .Q(\pc_out_reg[7] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [3]),
        .Q(\pc_out_reg[7] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [4]),
        .Q(\pc_out_reg[7] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [5]),
        .Q(\pc_out_reg[7] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [6]),
        .Q(\pc_out_reg[7] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \ir_out_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(\state_reg[0] ),
        .CLR(AR),
        .D(\instr_word_reg[7] [7]),
        .Q(\pc_out_reg[7] [6]));
  LUT3 #(
    .INIT(8'h8B)) 
    \pc_out[0]_i_1 
       (.I0(ir_out),
        .I1(pc_load),
        .I2(\pc_out_reg[0]_0 ),
        .O(\pc_out_reg[0] ));
  LUT6 #(
    .INIT(64'hAAAAAAAAFBBBBBBB)) 
    \pc_out[7]_i_1 
       (.I0(pc_load),
        .I1(\state_reg[1] [1]),
        .I2(zero_flag_reg),
        .I3(\pc_out_reg[7] [5]),
        .I4(\pc_out_reg[7] [6]),
        .I5(\state_reg[1] [0]),
        .O(E));
  LUT6 #(
    .INIT(64'h0040004044440044)) 
    \pc_out[7]_i_3 
       (.I0(\pc_out[7]_i_6_n_0 ),
        .I1(\state_reg[1]_0 ),
        .I2(zf),
        .I3(\pc_out_reg[7] [4]),
        .I4(cf),
        .I5(\pc_out_reg[7] [3]),
        .O(pc_load));
  LUT2 #(
    .INIT(4'h7)) 
    \pc_out[7]_i_6 
       (.I0(\pc_out_reg[7] [6]),
        .I1(\pc_out_reg[7] [5]),
        .O(\pc_out[7]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'h10)) 
    \pin[0][7]_i_1 
       (.I0(\pc_out_reg[7] [1]),
        .I1(ir_out),
        .I2(\pin[0][7]_i_2_n_0 ),
        .O(\pin_reg[0][7] ));
  LUT6 #(
    .INIT(64'h0000000075570000)) 
    \pin[0][7]_i_2 
       (.I0(\pc_out_reg[7] [6]),
        .I1(\pc_out_reg[7] [5]),
        .I2(\pc_out_reg[7] [3]),
        .I3(\pc_out_reg[7] [4]),
        .I4(\state_reg[1]_0 ),
        .I5(\pc_out_reg[7] [0]),
        .O(\pin[0][7]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \pin[1][7]_i_1 
       (.I0(\pc_out_reg[7] [1]),
        .I1(ir_out),
        .I2(\pin[0][7]_i_2_n_0 ),
        .O(\pin_reg[1][7] ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h10)) 
    \pin[2][7]_i_1 
       (.I0(\pc_out_reg[7] [1]),
        .I1(ir_out),
        .I2(\pin[2][7]_i_2_n_0 ),
        .O(\pin_reg[2][7] ));
  LUT6 #(
    .INIT(64'h7557000000000000)) 
    \pin[2][7]_i_2 
       (.I0(\pc_out_reg[7] [6]),
        .I1(\pc_out_reg[7] [5]),
        .I2(\pc_out_reg[7] [3]),
        .I3(\pc_out_reg[7] [4]),
        .I4(\state_reg[1]_0 ),
        .I5(\pc_out_reg[7] [0]),
        .O(\pin[2][7]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \pin[3][7]_i_1 
       (.I0(\pc_out_reg[7] [1]),
        .I1(ir_out),
        .I2(\pin[2][7]_i_2_n_0 ),
        .O(\pin_reg[3][7] ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \pin[4][7]_i_1 
       (.I0(ir_out),
        .I1(\pc_out_reg[7] [1]),
        .I2(\pin[0][7]_i_2_n_0 ),
        .O(\pin_reg[4][7] ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \pin[5][7]_i_1 
       (.I0(\pc_out_reg[7] [1]),
        .I1(ir_out),
        .I2(\pin[0][7]_i_2_n_0 ),
        .O(\pin_reg[5][7] ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \pin[6][7]_i_1 
       (.I0(ir_out),
        .I1(\pc_out_reg[7] [1]),
        .I2(\pin[2][7]_i_2_n_0 ),
        .O(\pin_reg[6][7] ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \pin[7][7]_i_1 
       (.I0(\pc_out_reg[7] [1]),
        .I1(ir_out),
        .I2(\pin[2][7]_i_2_n_0 ),
        .O(\pin_reg[7][7] ));
  LUT6 #(
    .INIT(64'h0000800000000000)) 
    \port_out[7]_i_1 
       (.I0(\pc_out_reg[7] [6]),
        .I1(\pc_out_reg[7] [5]),
        .I2(\pc_out_reg[7] [3]),
        .I3(\pc_out_reg[7] [4]),
        .I4(\state_reg[1] [0]),
        .I5(\state_reg[1] [1]),
        .O(\port_out_reg[7] ));
  LUT5 #(
    .INIT(32'h00000002)) 
    zero_flag_i_1
       (.I0(zero_flag_i_2_n_0),
        .I1(D[0]),
        .I2(D[5]),
        .I3(D[6]),
        .I4(D[7]),
        .O(alu_zero));
  LUT4 #(
    .INIT(16'h0001)) 
    zero_flag_i_2
       (.I0(D[2]),
        .I1(D[1]),
        .I2(D[4]),
        .I3(D[3]),
        .O(zero_flag_i_2_n_0));
endmodule

(* ECO_CHECKSUM = "ba591c75" *) 
(* NotValidForBitStream *)
module microprocessor_top
   (clk,
    rst,
    port_out);
  input clk;
  input rst;
  output [7:0]port_out;

  wire ACC_n_10;
  wire ACC_n_11;
  wire ACC_n_12;
  wire ACC_n_13;
  wire ACC_n_14;
  wire ACC_n_15;
  wire ACC_n_16;
  wire ACC_n_17;
  wire ACC_n_18;
  wire ACC_n_19;
  wire ACC_n_20;
  wire ACC_n_21;
  wire ACC_n_22;
  wire ACC_n_23;
  wire ACC_n_24;
  wire ACC_n_25;
  wire ACC_n_26;
  wire ACC_n_27;
  wire ACC_n_28;
  wire ACC_n_29;
  wire ACC_n_30;
  wire ACC_n_31;
  wire ACC_n_32;
  wire ACC_n_33;
  wire ACC_n_34;
  wire ACC_n_35;
  wire ACC_n_36;
  wire ACC_n_37;
  wire ACC_n_38;
  wire ACC_n_39;
  wire ACC_n_40;
  wire ACC_n_9;
  wire ALU_n_10;
  wire ALU_n_11;
  wire ALU_n_12;
  wire ALU_n_13;
  wire ALU_n_14;
  wire ALU_n_15;
  wire ALU_n_16;
  wire ALU_n_17;
  wire ALU_n_18;
  wire ALU_n_23;
  wire ALU_n_24;
  wire ALU_n_25;
  wire ALU_n_26;
  wire ALU_n_27;
  wire ALU_n_28;
  wire ALU_n_29;
  wire ALU_n_30;
  wire ALU_n_31;
  wire ALU_n_32;
  wire ALU_n_8;
  wire ALU_n_9;
  wire CU_n_0;
  wire FLAGS_n_2;
  wire IR_n_20;
  wire IR_n_22;
  wire IR_n_23;
  wire IR_n_24;
  wire IR_n_25;
  wire IR_n_26;
  wire IR_n_27;
  wire IR_n_28;
  wire IR_n_29;
  wire IR_n_30;
  wire IR_n_32;
  wire IR_n_33;
  wire IR_n_34;
  wire IR_n_35;
  wire IR_n_36;
  wire IR_n_37;
  wire IR_n_38;
  wire IR_n_39;
  wire IR_n_40;
  wire PC_n_1;
  wire PC_n_2;
  wire PC_n_3;
  wire PC_n_4;
  wire PC_n_5;
  wire PC_n_6;
  wire PC_n_7;
  wire PC_n_8;
  wire PC_n_9;
  wire REG_n_0;
  wire REG_n_12;
  wire REG_n_13;
  wire REG_n_14;
  wire REG_n_15;
  wire REG_n_16;
  wire REG_n_17;
  wire REG_n_18;
  wire REG_n_19;
  wire REG_n_20;
  wire REG_n_21;
  wire REG_n_22;
  wire REG_n_23;
  wire REG_n_24;
  wire REG_n_25;
  wire REG_n_26;
  wire REG_n_27;
  wire REG_n_28;
  wire REG_n_29;
  wire REG_n_3;
  wire REG_n_30;
  wire REG_n_31;
  wire REG_n_32;
  wire REG_n_33;
  wire REG_n_34;
  wire REG_n_35;
  wire REG_n_36;
  wire REG_n_37;
  wire REG_n_38;
  wire REG_n_39;
  wire REG_n_40;
  wire REG_n_41;
  wire REG_n_42;
  wire REG_n_43;
  wire REG_n_44;
  wire REG_n_45;
  wire REG_n_46;
  wire REG_n_47;
  wire REG_n_48;
  wire REG_n_49;
  wire REG_n_50;
  wire REG_n_51;
  wire REG_n_52;
  wire REG_n_53;
  wire REG_n_54;
  wire REG_n_55;
  wire REG_n_56;
  wire REG_n_57;
  wire REG_n_58;
  wire REG_n_59;
  wire REG_n_60;
  wire REG_n_61;
  wire REG_n_62;
  wire REG_n_63;
  wire REG_n_64;
  wire REG_n_65;
  wire REG_n_66;
  wire REG_n_67;
  wire REG_n_68;
  wire REG_n_69;
  wire REG_n_70;
  wire REG_n_71;
  wire REG_n_72;
  wire acc_load;
  wire [7:0]acc_out;
  wire alu_carry;
  wire [1:0]alu_opcode;
  wire alu_zero;
  wire cf;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire [7:0]data2;
  wire [7:0]data4;
  wire [7:0]instr_word;
  wire ir_load;
  wire [7:1]ir_out;
  wire out_write;
  wire [0:0]p_0_in;
  wire [0:0]pc_addr;
  wire pc_load;
  wire [7:0]pin;
  wire [7:0]port_out;
  wire [7:0]port_out_OBUF;
  wire [7:0]result;
  wire rst;
  wire rst_IBUF;
  wire [0:0]sel0;
  wire [1:0]state;
  wire zf;

  accumulator ACC
       (.AR(rst_IBUF),
        .D(result),
        .DI(ACC_n_13),
        .E(acc_load),
        .O({ACC_n_25,ACC_n_26,ACC_n_27,ACC_n_28}),
        .Q(acc_out),
        .S({ACC_n_11,ACC_n_12}),
        .alu_carry(alu_carry),
        .alu_opcode(alu_opcode[0]),
        .carry_flag_reg(ACC_n_9),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\ir_out_reg[4] (IR_n_30),
        .pin(pin),
        .\pin_reg[0][1] (ACC_n_40),
        .\pin_reg[0][2] (ACC_n_24),
        .\pin_reg[0][2]_0 (ACC_n_39),
        .\pin_reg[0][3] (ACC_n_17),
        .\pin_reg[0][3]_0 ({ACC_n_18,ACC_n_19}),
        .\pin_reg[0][3]_1 (ACC_n_23),
        .\pin_reg[0][3]_2 ({ACC_n_33,ACC_n_34}),
        .\pin_reg[0][4] (ACC_n_22),
        .\pin_reg[0][4]_0 (ACC_n_38),
        .\pin_reg[0][5] (ACC_n_21),
        .\pin_reg[0][5]_0 (ACC_n_37),
        .\pin_reg[0][6] (ACC_n_14),
        .\pin_reg[0][6]_0 (ACC_n_15),
        .\pin_reg[0][6]_1 (ACC_n_16),
        .\pin_reg[0][6]_2 (ACC_n_36),
        .\pin_reg[0][7] (ACC_n_10),
        .\pin_reg[0][7]_0 (ACC_n_20),
        .\pin_reg[0][7]_1 ({ACC_n_29,ACC_n_30,ACC_n_31,ACC_n_32}),
        .\pin_reg[0][7]_2 (ACC_n_35));
  alu ALU
       (.CO(REG_n_32),
        .DI({IR_n_36,IR_n_37,IR_n_38,IR_n_39}),
        .O({ALU_n_8,ALU_n_9,ALU_n_10,ALU_n_11}),
        .Q(acc_out[5:4]),
        .S({ACC_n_33,ACC_n_34,REG_n_40,IR_n_40}),
        .\acc_out_reg[0] (REG_n_45),
        .\acc_out_reg[0]_0 (REG_n_19),
        .\acc_out_reg[1] ({REG_n_43,ACC_n_11,REG_n_44,ACC_n_12}),
        .\acc_out_reg[1]_0 ({REG_n_33,REG_n_34,REG_n_35,acc_out[0]}),
        .\acc_out_reg[1]_1 ({REG_n_36,REG_n_37,REG_n_38,REG_n_39}),
        .\acc_out_reg[1]_2 (REG_n_70),
        .\acc_out_reg[2] ({ACC_n_18,REG_n_41,REG_n_42,ACC_n_19}),
        .\acc_out_reg[2]_0 (REG_n_20),
        .\acc_out_reg[3] ({REG_n_26,REG_n_27,ACC_n_17}),
        .\acc_out_reg[3]_0 ({REG_n_21,REG_n_22,ACC_n_13}),
        .\acc_out_reg[5] ({IR_n_33,IR_n_34,IR_n_35}),
        .\acc_out_reg[5]_0 ({REG_n_23,REG_n_24,REG_n_25}),
        .\acc_out_reg[5]_1 ({REG_n_28,REG_n_29,REG_n_30,REG_n_31}),
        .\acc_out_reg[5]_2 (REG_n_61),
        .\acc_out_reg[6] ({REG_n_16,REG_n_17,REG_n_18,ACC_n_35}),
        .\acc_out_reg[7] ({REG_n_46,REG_n_47,REG_n_48,REG_n_49}),
        .alu_opcode(alu_opcode),
        .data2(data2),
        .data4({data4[7],data4[1]}),
        .\ir_out_reg[5] ({REG_n_50,REG_n_51,REG_n_52,acc_out[6]}),
        .\ir_out_reg[5]_0 ({REG_n_57,REG_n_58,REG_n_59,REG_n_60}),
        .\ir_out_reg[5]_1 ({REG_n_53,REG_n_54,REG_n_55,REG_n_56}),
        .\ir_out_reg[5]_2 (REG_n_71),
        .\ir_out_reg[5]_3 (REG_n_72),
        .\ir_out_reg[5]_4 ({REG_n_62,REG_n_63,REG_n_64,REG_n_65}),
        .\ir_out_reg[5]_5 ({REG_n_66,REG_n_67,REG_n_68,REG_n_69}),
        .pin(pin),
        .\pin_reg[0][3] (ALU_n_32),
        .\pin_reg[0][4] (ALU_n_23),
        .\pin_reg[0][4]_0 ({ALU_n_25,ALU_n_26,ALU_n_27,ALU_n_28}),
        .\pin_reg[0][4]_1 ({ALU_n_29,ALU_n_30}),
        .\pin_reg[0][4]_2 (ALU_n_31),
        .\pin_reg[0][5] (ALU_n_24),
        .\pin_reg[0][6] ({ALU_n_14,ALU_n_15}),
        .\pin_reg[0][6]_0 (ALU_n_17),
        .\pin_reg[0][6]_1 ({data4[6:4],data4[0]}),
        .\pin_reg[0][7] ({ALU_n_12,ALU_n_13}),
        .\pin_reg[0][7]_0 (ALU_n_16),
        .\pin_reg[0][7]_1 (ALU_n_18));
  control_unit CU
       (.AR(rst_IBUF),
        .D(ir_load),
        .Q(state),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\pc_out_reg[0] (CU_n_0));
  flags_register FLAGS
       (.AR(rst_IBUF),
        .E(acc_load),
        .Q(ir_out[5:4]),
        .alu_carry(alu_carry),
        .alu_zero(alu_zero),
        .cf(cf),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\pc_out_reg[7] (FLAGS_n_2),
        .zf(zf));
  instruction_memory IMEM
       (.D(instr_word),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\pc_out_reg[0] ({PC_n_1,PC_n_2,PC_n_3,PC_n_4}),
        .\pc_out_reg[1] (PC_n_9),
        .\pc_out_reg[2] (PC_n_8),
        .\pc_out_reg[3] (PC_n_6),
        .\pc_out_reg[3]_0 (PC_n_7),
        .\pc_out_reg[7] (PC_n_5));
  instruction_register IR
       (.AR(rst_IBUF),
        .D(result),
        .DI({IR_n_36,IR_n_37,IR_n_38,IR_n_39}),
        .E(IR_n_20),
        .O({ACC_n_25,ACC_n_26,ACC_n_27,ACC_n_28}),
        .Q(acc_out),
        .S(IR_n_40),
        .\acc_out_reg[0] (REG_n_3),
        .\acc_out_reg[0]_0 (ALU_n_18),
        .\acc_out_reg[1] (ACC_n_40),
        .\acc_out_reg[1]_0 (REG_n_12),
        .\acc_out_reg[1]_1 (ACC_n_24),
        .\acc_out_reg[2] (ACC_n_39),
        .\acc_out_reg[2]_0 (REG_n_13),
        .\acc_out_reg[2]_1 (ACC_n_23),
        .\acc_out_reg[3] (ACC_n_22),
        .\acc_out_reg[4] (ACC_n_38),
        .\acc_out_reg[4]_0 (ALU_n_23),
        .\acc_out_reg[4]_1 (ACC_n_21),
        .\acc_out_reg[5] (ACC_n_37),
        .\acc_out_reg[5]_0 (ALU_n_24),
        .\acc_out_reg[5]_1 (ACC_n_9),
        .\acc_out_reg[6] (ACC_n_36),
        .\acc_out_reg[6]_0 (REG_n_14),
        .\acc_out_reg[6]_1 (ACC_n_20),
        .\acc_out_reg[7] ({ACC_n_29,ACC_n_30,ACC_n_31,ACC_n_32}),
        .alu_zero(alu_zero),
        .carry_flag_reg(IR_n_30),
        .carry_flag_reg_0(acc_load),
        .cf(cf),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .data2(data2),
        .\instr_word_reg[7] (instr_word),
        .\ir_out_reg[5]_0 (REG_n_15),
        .\ir_out_reg[7]_0 (REG_n_0),
        .pc_load(pc_load),
        .\pc_out_reg[0] (p_0_in),
        .\pc_out_reg[0]_0 (pc_addr),
        .\pc_out_reg[7] ({ir_out[7:4],sel0,ir_out[2:1]}),
        .pin({pin[7],pin[5:0]}),
        .\pin_reg[0][3] (alu_opcode),
        .\pin_reg[0][7] (IR_n_29),
        .\pin_reg[0][7]_0 (IR_n_32),
        .\pin_reg[0][7]_1 ({IR_n_33,IR_n_34,IR_n_35}),
        .\pin_reg[1][7] (IR_n_28),
        .\pin_reg[2][7] (IR_n_25),
        .\pin_reg[3][7] (IR_n_24),
        .\pin_reg[4][7] (IR_n_27),
        .\pin_reg[5][7] (IR_n_26),
        .\pin_reg[6][7] (IR_n_23),
        .\pin_reg[7][7] (IR_n_22),
        .\port_out_reg[7] (out_write),
        .\state_reg[0] (ir_load),
        .\state_reg[1] (state),
        .\state_reg[1]_0 (CU_n_0),
        .zero_flag_reg(FLAGS_n_2),
        .zf(zf));
  output_port OUTP
       (.AR(rst_IBUF),
        .E(out_write),
        .Q(port_out_OBUF),
        .\acc_out_reg[7] (acc_out),
        .clk_IBUF_BUFG(clk_IBUF_BUFG));
  program_counter PC
       (.AR(rst_IBUF),
        .D(p_0_in),
        .E(IR_n_20),
        .Q(pc_addr),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\instr_word_reg[0] (PC_n_5),
        .\instr_word_reg[0]_0 (PC_n_7),
        .\instr_word_reg[1] (PC_n_8),
        .\instr_word_reg[2] (PC_n_9),
        .\instr_word_reg[6] (PC_n_6),
        .\instr_word_reg[7] ({PC_n_1,PC_n_2,PC_n_3,PC_n_4}),
        .\ir_out_reg[7] ({ir_out[7:4],sel0,ir_out[2:1]}),
        .pc_load(pc_load));
  register REG
       (.CO(REG_n_32),
        .D(result),
        .E(IR_n_29),
        .O({ALU_n_8,ALU_n_9,ALU_n_10,ALU_n_11}),
        .Q(acc_out),
        .S(REG_n_40),
        .\acc_out_reg[0] (ALU_n_17),
        .\acc_out_reg[1] (ACC_n_10),
        .\acc_out_reg[2] (ALU_n_16),
        .\acc_out_reg[2]_0 (ACC_n_14),
        .\acc_out_reg[3] ({ALU_n_14,ALU_n_15}),
        .\acc_out_reg[3]_0 (ACC_n_15),
        .\acc_out_reg[4] (ACC_n_16),
        .\acc_out_reg[4]_0 (ALU_n_32),
        .\acc_out_reg[5] ({ALU_n_12,ALU_n_13}),
        .\acc_out_reg[5]_0 ({ALU_n_29,ALU_n_30}),
        .\acc_out_reg[5]_1 ({ALU_n_25,ALU_n_26,ALU_n_27,ALU_n_28}),
        .\acc_out_reg[5]_2 (ALU_n_31),
        .\acc_out_reg[6] ({data4[6:4],data4[0]}),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\ir_out_reg[0] (IR_n_27),
        .\ir_out_reg[0]_0 (IR_n_23),
        .\ir_out_reg[2] (IR_n_28),
        .\ir_out_reg[2]_0 (IR_n_25),
        .\ir_out_reg[2]_1 (IR_n_24),
        .\ir_out_reg[2]_2 (IR_n_26),
        .\ir_out_reg[2]_3 (IR_n_22),
        .\ir_out_reg[4] (IR_n_32),
        .\ir_out_reg[5] ({ir_out[5:4],sel0}),
        .\ir_out_reg[7] (alu_opcode),
        .pin(pin),
        .\pin_reg[0][0]_0 (REG_n_3),
        .\pin_reg[0][0]_1 ({REG_n_33,REG_n_34,REG_n_35}),
        .\pin_reg[0][0]_2 ({REG_n_36,REG_n_37,REG_n_38,REG_n_39}),
        .\pin_reg[0][0]_3 ({REG_n_62,REG_n_63,REG_n_64,REG_n_65}),
        .\pin_reg[0][0]_4 ({REG_n_66,REG_n_67,REG_n_68,REG_n_69}),
        .\pin_reg[0][0]_5 (REG_n_70),
        .\pin_reg[0][1]_0 (REG_n_12),
        .\pin_reg[0][2]_0 (REG_n_13),
        .\pin_reg[0][3]_0 (REG_n_0),
        .\pin_reg[0][3]_1 ({REG_n_21,REG_n_22}),
        .\pin_reg[0][3]_2 ({REG_n_26,REG_n_27}),
        .\pin_reg[0][3]_3 ({REG_n_41,REG_n_42}),
        .\pin_reg[0][3]_4 ({REG_n_43,REG_n_44}),
        .\pin_reg[0][4]_0 (REG_n_61),
        .\pin_reg[0][6]_0 ({data4[7],data4[1]}),
        .\pin_reg[0][6]_1 (REG_n_14),
        .\pin_reg[0][6]_10 (REG_n_72),
        .\pin_reg[0][6]_2 ({REG_n_23,REG_n_24,REG_n_25}),
        .\pin_reg[0][6]_3 ({REG_n_28,REG_n_29,REG_n_30,REG_n_31}),
        .\pin_reg[0][6]_4 (REG_n_45),
        .\pin_reg[0][6]_5 ({REG_n_46,REG_n_47,REG_n_48,REG_n_49}),
        .\pin_reg[0][6]_6 ({REG_n_50,REG_n_51,REG_n_52}),
        .\pin_reg[0][6]_7 ({REG_n_53,REG_n_54,REG_n_55,REG_n_56}),
        .\pin_reg[0][6]_8 ({REG_n_57,REG_n_58,REG_n_59,REG_n_60}),
        .\pin_reg[0][6]_9 (REG_n_71),
        .\pin_reg[0][7]_0 (REG_n_15),
        .\pin_reg[0][7]_1 ({REG_n_16,REG_n_17,REG_n_18}),
        .\pin_reg[0][7]_2 (REG_n_19),
        .\pin_reg[0][7]_3 (REG_n_20));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  OBUF \port_out_OBUF[0]_inst 
       (.I(port_out_OBUF[0]),
        .O(port_out[0]));
  OBUF \port_out_OBUF[1]_inst 
       (.I(port_out_OBUF[1]),
        .O(port_out[1]));
  OBUF \port_out_OBUF[2]_inst 
       (.I(port_out_OBUF[2]),
        .O(port_out[2]));
  OBUF \port_out_OBUF[3]_inst 
       (.I(port_out_OBUF[3]),
        .O(port_out[3]));
  OBUF \port_out_OBUF[4]_inst 
       (.I(port_out_OBUF[4]),
        .O(port_out[4]));
  OBUF \port_out_OBUF[5]_inst 
       (.I(port_out_OBUF[5]),
        .O(port_out[5]));
  OBUF \port_out_OBUF[6]_inst 
       (.I(port_out_OBUF[6]),
        .O(port_out[6]));
  OBUF \port_out_OBUF[7]_inst 
       (.I(port_out_OBUF[7]),
        .O(port_out[7]));
  IBUF rst_IBUF_inst
       (.I(rst),
        .O(rst_IBUF));
endmodule

module output_port
   (Q,
    E,
    \acc_out_reg[7] ,
    clk_IBUF_BUFG,
    AR);
  output [7:0]Q;
  input [0:0]E;
  input [7:0]\acc_out_reg[7] ;
  input clk_IBUF_BUFG;
  input [0:0]AR;

  wire [0:0]AR;
  wire [0:0]E;
  wire [7:0]Q;
  wire [7:0]\acc_out_reg[7] ;
  wire clk_IBUF_BUFG;

  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [0]),
        .Q(Q[0]));
  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [1]),
        .Q(Q[1]));
  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [2]),
        .Q(Q[2]));
  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [3]),
        .Q(Q[3]));
  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [4]),
        .Q(Q[4]));
  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [5]),
        .Q(Q[5]));
  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [6]),
        .Q(Q[6]));
  FDCE #(
    .INIT(1'b0)) 
    \port_out_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(\acc_out_reg[7] [7]),
        .Q(Q[7]));
endmodule

module program_counter
   (Q,
    \instr_word_reg[7] ,
    \instr_word_reg[0] ,
    \instr_word_reg[6] ,
    \instr_word_reg[0]_0 ,
    \instr_word_reg[1] ,
    \instr_word_reg[2] ,
    D,
    pc_load,
    \ir_out_reg[7] ,
    E,
    clk_IBUF_BUFG,
    AR);
  output [0:0]Q;
  output [3:0]\instr_word_reg[7] ;
  output \instr_word_reg[0] ;
  output \instr_word_reg[6] ;
  output \instr_word_reg[0]_0 ;
  output \instr_word_reg[1] ;
  output \instr_word_reg[2] ;
  input [0:0]D;
  input pc_load;
  input [6:0]\ir_out_reg[7] ;
  input [0:0]E;
  input clk_IBUF_BUFG;
  input [0:0]AR;

  wire [0:0]AR;
  wire [0:0]D;
  wire [0:0]E;
  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \instr_word_reg[0] ;
  wire \instr_word_reg[0]_0 ;
  wire \instr_word_reg[1] ;
  wire \instr_word_reg[2] ;
  wire \instr_word_reg[6] ;
  wire [3:0]\instr_word_reg[7] ;
  wire [6:0]\ir_out_reg[7] ;
  wire [7:1]p_0_in;
  wire [7:1]pc_addr;
  wire pc_load;
  wire \pc_out[4]_i_2_n_0 ;
  wire \pc_out[5]_i_2_n_0 ;
  wire \pc_out[7]_i_5_n_0 ;

  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'h1110)) 
    \instr_word[0]_i_1 
       (.I0(pc_addr[3]),
        .I1(pc_addr[2]),
        .I2(Q),
        .I3(pc_addr[1]),
        .O(\instr_word_reg[0]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'h0004)) 
    \instr_word[1]_i_1 
       (.I0(pc_addr[2]),
        .I1(pc_addr[3]),
        .I2(Q),
        .I3(pc_addr[1]),
        .O(\instr_word_reg[1] ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'h0440)) 
    \instr_word[2]_i_1 
       (.I0(pc_addr[1]),
        .I1(Q),
        .I2(pc_addr[3]),
        .I3(pc_addr[2]),
        .O(\instr_word_reg[2] ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h00000413)) 
    \instr_word[3]_i_1 
       (.I0(pc_addr[1]),
        .I1(pc_addr[2]),
        .I2(pc_addr[3]),
        .I3(Q),
        .I4(\instr_word_reg[0] ),
        .O(\instr_word_reg[7] [0]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'h00010151)) 
    \instr_word[4]_i_1 
       (.I0(\instr_word_reg[0] ),
        .I1(pc_addr[3]),
        .I2(Q),
        .I3(pc_addr[1]),
        .I4(pc_addr[2]),
        .O(\instr_word_reg[7] [1]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'h00010103)) 
    \instr_word[5]_i_1 
       (.I0(Q),
        .I1(\instr_word_reg[0] ),
        .I2(pc_addr[3]),
        .I3(pc_addr[1]),
        .I4(pc_addr[2]),
        .O(\instr_word_reg[7] [2]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \instr_word[6]_i_1 
       (.I0(pc_addr[7]),
        .I1(pc_addr[6]),
        .I2(pc_addr[4]),
        .I3(pc_addr[5]),
        .O(\instr_word_reg[0] ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \instr_word[6]_i_2 
       (.I0(pc_addr[3]),
        .I1(pc_addr[2]),
        .I2(pc_addr[1]),
        .O(\instr_word_reg[6] ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h0000001F)) 
    \instr_word[7]_i_1 
       (.I0(Q),
        .I1(pc_addr[2]),
        .I2(pc_addr[1]),
        .I3(\instr_word_reg[0] ),
        .I4(pc_addr[3]),
        .O(\instr_word_reg[7] [3]));
  LUT4 #(
    .INIT(16'hF606)) 
    \pc_out[1]_i_1 
       (.I0(pc_addr[1]),
        .I1(Q),
        .I2(pc_load),
        .I3(\ir_out_reg[7] [0]),
        .O(p_0_in[1]));
  LUT5 #(
    .INIT(32'hFF6A006A)) 
    \pc_out[2]_i_1 
       (.I0(pc_addr[2]),
        .I1(pc_addr[1]),
        .I2(Q),
        .I3(pc_load),
        .I4(\ir_out_reg[7] [1]),
        .O(p_0_in[2]));
  LUT6 #(
    .INIT(64'hFFFF6AAA00006AAA)) 
    \pc_out[3]_i_1 
       (.I0(pc_addr[3]),
        .I1(pc_addr[2]),
        .I2(Q),
        .I3(pc_addr[1]),
        .I4(pc_load),
        .I5(\ir_out_reg[7] [2]),
        .O(p_0_in[3]));
  LUT4 #(
    .INIT(16'hF606)) 
    \pc_out[4]_i_1 
       (.I0(pc_addr[4]),
        .I1(\pc_out[4]_i_2_n_0 ),
        .I2(pc_load),
        .I3(\ir_out_reg[7] [3]),
        .O(p_0_in[4]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \pc_out[4]_i_2 
       (.I0(pc_addr[3]),
        .I1(pc_addr[1]),
        .I2(Q),
        .I3(pc_addr[2]),
        .O(\pc_out[4]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hF606)) 
    \pc_out[5]_i_1 
       (.I0(pc_addr[5]),
        .I1(\pc_out[5]_i_2_n_0 ),
        .I2(pc_load),
        .I3(\ir_out_reg[7] [4]),
        .O(p_0_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \pc_out[5]_i_2 
       (.I0(pc_addr[4]),
        .I1(pc_addr[2]),
        .I2(Q),
        .I3(pc_addr[1]),
        .I4(pc_addr[3]),
        .O(\pc_out[5]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hF606)) 
    \pc_out[6]_i_1 
       (.I0(pc_addr[6]),
        .I1(\pc_out[7]_i_5_n_0 ),
        .I2(pc_load),
        .I3(\ir_out_reg[7] [5]),
        .O(p_0_in[6]));
  LUT5 #(
    .INIT(32'hFF6A006A)) 
    \pc_out[7]_i_2 
       (.I0(pc_addr[7]),
        .I1(\pc_out[7]_i_5_n_0 ),
        .I2(pc_addr[6]),
        .I3(pc_load),
        .I4(\ir_out_reg[7] [6]),
        .O(p_0_in[7]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \pc_out[7]_i_5 
       (.I0(pc_addr[5]),
        .I1(pc_addr[3]),
        .I2(pc_addr[1]),
        .I3(Q),
        .I4(pc_addr[2]),
        .I5(pc_addr[4]),
        .O(\pc_out[7]_i_5_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(D),
        .Q(Q));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(p_0_in[1]),
        .Q(pc_addr[1]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(p_0_in[2]),
        .Q(pc_addr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(p_0_in[3]),
        .Q(pc_addr[3]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(p_0_in[4]),
        .Q(pc_addr[4]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(p_0_in[5]),
        .Q(pc_addr[5]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(p_0_in[6]),
        .Q(pc_addr[6]));
  FDCE #(
    .INIT(1'b0)) 
    \pc_out_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .CLR(AR),
        .D(p_0_in[7]),
        .Q(pc_addr[7]));
endmodule

module register
   (\pin_reg[0][3]_0 ,
    \pin_reg[0][6]_0 ,
    \pin_reg[0][0]_0 ,
    pin,
    \pin_reg[0][1]_0 ,
    \pin_reg[0][2]_0 ,
    \pin_reg[0][6]_1 ,
    \pin_reg[0][7]_0 ,
    \pin_reg[0][7]_1 ,
    \pin_reg[0][7]_2 ,
    \pin_reg[0][7]_3 ,
    \pin_reg[0][3]_1 ,
    \pin_reg[0][6]_2 ,
    \pin_reg[0][3]_2 ,
    \pin_reg[0][6]_3 ,
    CO,
    \pin_reg[0][0]_1 ,
    \pin_reg[0][0]_2 ,
    S,
    \pin_reg[0][3]_3 ,
    \pin_reg[0][3]_4 ,
    \pin_reg[0][6]_4 ,
    \pin_reg[0][6]_5 ,
    \pin_reg[0][6]_6 ,
    \pin_reg[0][6]_7 ,
    \pin_reg[0][6]_8 ,
    \pin_reg[0][4]_0 ,
    \pin_reg[0][0]_3 ,
    \pin_reg[0][0]_4 ,
    \pin_reg[0][0]_5 ,
    \pin_reg[0][6]_9 ,
    \pin_reg[0][6]_10 ,
    \acc_out_reg[6] ,
    O,
    \acc_out_reg[3] ,
    \ir_out_reg[7] ,
    Q,
    \acc_out_reg[0] ,
    \ir_out_reg[4] ,
    \acc_out_reg[5] ,
    \acc_out_reg[2] ,
    \ir_out_reg[5] ,
    \acc_out_reg[1] ,
    \acc_out_reg[4] ,
    \acc_out_reg[5]_0 ,
    \acc_out_reg[5]_1 ,
    \acc_out_reg[2]_0 ,
    \acc_out_reg[3]_0 ,
    \acc_out_reg[5]_2 ,
    \acc_out_reg[4]_0 ,
    E,
    D,
    clk_IBUF_BUFG,
    \ir_out_reg[2] ,
    \ir_out_reg[2]_0 ,
    \ir_out_reg[2]_1 ,
    \ir_out_reg[0] ,
    \ir_out_reg[2]_2 ,
    \ir_out_reg[0]_0 ,
    \ir_out_reg[2]_3 );
  output \pin_reg[0][3]_0 ;
  output [1:0]\pin_reg[0][6]_0 ;
  output \pin_reg[0][0]_0 ;
  output [7:0]pin;
  output \pin_reg[0][1]_0 ;
  output \pin_reg[0][2]_0 ;
  output \pin_reg[0][6]_1 ;
  output \pin_reg[0][7]_0 ;
  output [2:0]\pin_reg[0][7]_1 ;
  output [0:0]\pin_reg[0][7]_2 ;
  output [0:0]\pin_reg[0][7]_3 ;
  output [1:0]\pin_reg[0][3]_1 ;
  output [2:0]\pin_reg[0][6]_2 ;
  output [1:0]\pin_reg[0][3]_2 ;
  output [3:0]\pin_reg[0][6]_3 ;
  output [0:0]CO;
  output [2:0]\pin_reg[0][0]_1 ;
  output [3:0]\pin_reg[0][0]_2 ;
  output [0:0]S;
  output [1:0]\pin_reg[0][3]_3 ;
  output [1:0]\pin_reg[0][3]_4 ;
  output [0:0]\pin_reg[0][6]_4 ;
  output [3:0]\pin_reg[0][6]_5 ;
  output [2:0]\pin_reg[0][6]_6 ;
  output [3:0]\pin_reg[0][6]_7 ;
  output [3:0]\pin_reg[0][6]_8 ;
  output [0:0]\pin_reg[0][4]_0 ;
  output [3:0]\pin_reg[0][0]_3 ;
  output [3:0]\pin_reg[0][0]_4 ;
  output [0:0]\pin_reg[0][0]_5 ;
  output [0:0]\pin_reg[0][6]_9 ;
  output [0:0]\pin_reg[0][6]_10 ;
  input [3:0]\acc_out_reg[6] ;
  input [3:0]O;
  input [1:0]\acc_out_reg[3] ;
  input [1:0]\ir_out_reg[7] ;
  input [7:0]Q;
  input [0:0]\acc_out_reg[0] ;
  input \ir_out_reg[4] ;
  input [1:0]\acc_out_reg[5] ;
  input [0:0]\acc_out_reg[2] ;
  input [2:0]\ir_out_reg[5] ;
  input \acc_out_reg[1] ;
  input \acc_out_reg[4] ;
  input [1:0]\acc_out_reg[5]_0 ;
  input [3:0]\acc_out_reg[5]_1 ;
  input \acc_out_reg[2]_0 ;
  input \acc_out_reg[3]_0 ;
  input [0:0]\acc_out_reg[5]_2 ;
  input [0:0]\acc_out_reg[4]_0 ;
  input [0:0]E;
  input [7:0]D;
  input clk_IBUF_BUFG;
  input [0:0]\ir_out_reg[2] ;
  input [0:0]\ir_out_reg[2]_0 ;
  input [0:0]\ir_out_reg[2]_1 ;
  input [0:0]\ir_out_reg[0] ;
  input [0:0]\ir_out_reg[2]_2 ;
  input [0:0]\ir_out_reg[0]_0 ;
  input [0:0]\ir_out_reg[2]_3 ;

  wire [0:0]CO;
  wire [7:0]D;
  wire [0:0]E;
  wire [3:0]O;
  wire [7:0]Q;
  wire [0:0]S;
  wire \acc_out[0]_i_5_n_0 ;
  wire \acc_out[0]_i_6_n_0 ;
  wire \acc_out[3]_i_13_n_0 ;
  wire \acc_out[3]_i_14_n_0 ;
  wire \acc_out[4]_i_10_n_0 ;
  wire \acc_out[4]_i_11_n_0 ;
  wire \acc_out[4]_i_12_n_0 ;
  wire \acc_out[4]_i_13_n_0 ;
  wire [0:0]\acc_out_reg[0] ;
  wire \acc_out_reg[1] ;
  wire [0:0]\acc_out_reg[2] ;
  wire \acc_out_reg[2]_0 ;
  wire [1:0]\acc_out_reg[3] ;
  wire \acc_out_reg[3]_0 ;
  wire \acc_out_reg[3]_i_8_n_7 ;
  wire \acc_out_reg[4] ;
  wire [0:0]\acc_out_reg[4]_0 ;
  wire \acc_out_reg[4]_i_7_n_4 ;
  wire \acc_out_reg[4]_i_7_n_5 ;
  wire \acc_out_reg[4]_i_7_n_6 ;
  wire \acc_out_reg[4]_i_7_n_7 ;
  wire [1:0]\acc_out_reg[5] ;
  wire [1:0]\acc_out_reg[5]_0 ;
  wire [3:0]\acc_out_reg[5]_1 ;
  wire [0:0]\acc_out_reg[5]_2 ;
  wire [3:0]\acc_out_reg[6] ;
  wire clk_IBUF_BUFG;
  wire [3:2]data4;
  wire i___0_carry__0_i_12_n_0;
  wire i___0_carry__0_i_13_n_0;
  wire i___0_carry__0_i_14_n_0;
  wire i___0_carry__0_i_15_n_0;
  wire i___0_carry__0_i_16_n_0;
  wire i___0_carry__0_i_17_n_0;
  wire i___0_carry__0_i_18_n_0;
  wire i___0_carry__0_i_19_n_0;
  wire i___0_carry__0_i_9__0_n_0;
  wire i___0_carry_i_12_n_0;
  wire i___0_carry_i_13_n_0;
  wire i___0_carry_i_14_n_0;
  wire i___0_carry_i_15_n_0;
  wire i___0_carry_i_16_n_0;
  wire i___0_carry_i_17_n_0;
  wire i___211_carry__0_i_1_n_0;
  wire i___211_carry__0_i_6_n_0;
  wire i___211_carry__0_i_7_n_0;
  wire i___211_carry__0_i_8_n_0;
  wire i___211_carry__0_i_9_n_0;
  wire i___211_carry_i_10_n_0;
  wire i___211_carry_i_11_n_0;
  wire i___211_carry_i_11_n_4;
  wire i___211_carry_i_11_n_5;
  wire i___211_carry_i_11_n_6;
  wire i___211_carry_i_12_n_0;
  wire i___211_carry_i_13_n_0;
  wire i___211_carry_i_14_n_0;
  wire i___211_carry_i_15_n_0;
  wire i___211_carry_i_15_n_4;
  wire i___211_carry_i_15_n_5;
  wire i___211_carry_i_15_n_6;
  wire i___211_carry_i_15_n_7;
  wire i___211_carry_i_16_n_0;
  wire i___211_carry_i_17_n_0;
  wire i___211_carry_i_18_n_0;
  wire i___211_carry_i_18_n_4;
  wire i___211_carry_i_18_n_5;
  wire i___211_carry_i_18_n_6;
  wire i___211_carry_i_19_n_0;
  wire i___211_carry_i_1_n_7;
  wire i___211_carry_i_20_n_0;
  wire i___211_carry_i_21_n_0;
  wire i___211_carry_i_22_n_0;
  wire i___211_carry_i_23_n_0;
  wire i___211_carry_i_24_n_0;
  wire i___211_carry_i_25_n_0;
  wire i___211_carry_i_26_n_0;
  wire i___211_carry_i_26_n_4;
  wire i___211_carry_i_26_n_5;
  wire i___211_carry_i_26_n_6;
  wire i___211_carry_i_27_n_0;
  wire i___211_carry_i_28_n_0;
  wire i___211_carry_i_29_n_0;
  wire i___211_carry_i_2_n_0;
  wire i___211_carry_i_30_n_0;
  wire i___211_carry_i_31_n_0;
  wire i___211_carry_i_32_n_0;
  wire i___211_carry_i_33_n_0;
  wire i___211_carry_i_34_n_0;
  wire i___211_carry_i_35_n_0;
  wire i___211_carry_i_36_n_0;
  wire i___211_carry_i_7_n_7;
  wire i___211_carry_i_8_n_0;
  wire i___211_carry_i_8_n_4;
  wire i___211_carry_i_8_n_5;
  wire i___211_carry_i_8_n_6;
  wire i___211_carry_i_8_n_7;
  wire i___211_carry_i_9_n_0;
  wire i___22_carry__0_i_3_n_0;
  wire i___35_carry__0_i_2_n_0;
  wire i___7_carry__0_i_10_n_0;
  wire i___7_carry__0_i_9_n_0;
  wire i___7_carry_i_9_n_0;
  wire [0:0]\ir_out_reg[0] ;
  wire [0:0]\ir_out_reg[0]_0 ;
  wire [0:0]\ir_out_reg[2] ;
  wire [0:0]\ir_out_reg[2]_0 ;
  wire [0:0]\ir_out_reg[2]_1 ;
  wire [0:0]\ir_out_reg[2]_2 ;
  wire [0:0]\ir_out_reg[2]_3 ;
  wire \ir_out_reg[4] ;
  wire [2:0]\ir_out_reg[5] ;
  wire [1:0]\ir_out_reg[7] ;
  wire [7:0]pin;
  wire [7:0]\pin_reg[0] ;
  wire \pin_reg[0][0]_0 ;
  wire [2:0]\pin_reg[0][0]_1 ;
  wire [3:0]\pin_reg[0][0]_2 ;
  wire [3:0]\pin_reg[0][0]_3 ;
  wire [3:0]\pin_reg[0][0]_4 ;
  wire [0:0]\pin_reg[0][0]_5 ;
  wire \pin_reg[0][1]_0 ;
  wire \pin_reg[0][2]_0 ;
  wire \pin_reg[0][3]_0 ;
  wire [1:0]\pin_reg[0][3]_1 ;
  wire [1:0]\pin_reg[0][3]_2 ;
  wire [1:0]\pin_reg[0][3]_3 ;
  wire [1:0]\pin_reg[0][3]_4 ;
  wire [0:0]\pin_reg[0][4]_0 ;
  wire [1:0]\pin_reg[0][6]_0 ;
  wire \pin_reg[0][6]_1 ;
  wire [0:0]\pin_reg[0][6]_10 ;
  wire [2:0]\pin_reg[0][6]_2 ;
  wire [3:0]\pin_reg[0][6]_3 ;
  wire [0:0]\pin_reg[0][6]_4 ;
  wire [3:0]\pin_reg[0][6]_5 ;
  wire [2:0]\pin_reg[0][6]_6 ;
  wire [3:0]\pin_reg[0][6]_7 ;
  wire [3:0]\pin_reg[0][6]_8 ;
  wire [0:0]\pin_reg[0][6]_9 ;
  wire \pin_reg[0][7]_0 ;
  wire [2:0]\pin_reg[0][7]_1 ;
  wire [0:0]\pin_reg[0][7]_2 ;
  wire [0:0]\pin_reg[0][7]_3 ;
  wire [7:0]\pin_reg[1] ;
  wire [7:0]\pin_reg[2] ;
  wire [7:0]\pin_reg[3] ;
  wire [7:0]\pin_reg[4] ;
  wire [7:0]\pin_reg[5] ;
  wire [7:0]\pin_reg[6] ;
  wire [7:0]\pin_reg[7] ;
  wire [3:0]\NLW_acc_out_reg[3]_i_8_CO_UNCONNECTED ;
  wire [3:1]\NLW_acc_out_reg[3]_i_8_O_UNCONNECTED ;
  wire [2:0]\NLW_acc_out_reg[4]_i_7_CO_UNCONNECTED ;
  wire [2:0]NLW_i___211_carry__0_i_1_CO_UNCONNECTED;
  wire [3:0]NLW_i___211_carry_i_1_CO_UNCONNECTED;
  wire [3:1]NLW_i___211_carry_i_1_O_UNCONNECTED;
  wire [2:0]NLW_i___211_carry_i_11_CO_UNCONNECTED;
  wire [0:0]NLW_i___211_carry_i_11_O_UNCONNECTED;
  wire [2:0]NLW_i___211_carry_i_15_CO_UNCONNECTED;
  wire [2:0]NLW_i___211_carry_i_18_CO_UNCONNECTED;
  wire [0:0]NLW_i___211_carry_i_18_O_UNCONNECTED;
  wire [2:0]NLW_i___211_carry_i_2_CO_UNCONNECTED;
  wire [0:0]NLW_i___211_carry_i_2_O_UNCONNECTED;
  wire [2:0]NLW_i___211_carry_i_26_CO_UNCONNECTED;
  wire [0:0]NLW_i___211_carry_i_26_O_UNCONNECTED;
  wire [3:0]NLW_i___211_carry_i_7_CO_UNCONNECTED;
  wire [3:1]NLW_i___211_carry_i_7_O_UNCONNECTED;
  wire [2:0]NLW_i___211_carry_i_8_CO_UNCONNECTED;

  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    \acc_out[0]_i_5 
       (.I0(\pin_reg[1] [0]),
        .I1(\pin_reg[3] [0]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [0]),
        .I5(\pin_reg[2] [0]),
        .O(\acc_out[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    \acc_out[0]_i_6 
       (.I0(\pin_reg[5] [0]),
        .I1(\pin_reg[7] [0]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [0]),
        .I5(\pin_reg[6] [0]),
        .O(\acc_out[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFCFCFA0AFC0C0A0A)) 
    \acc_out[0]_i_7 
       (.I0(O[0]),
        .I1(\acc_out_reg[6] [0]),
        .I2(\ir_out_reg[7] [1]),
        .I3(Q[0]),
        .I4(\ir_out_reg[7] [0]),
        .I5(pin[0]),
        .O(\pin_reg[0][0]_0 ));
  LUT6 #(
    .INIT(64'hFCFCFC0CFA0A0A0A)) 
    \acc_out[1]_i_4 
       (.I0(O[1]),
        .I1(\pin_reg[0][6]_0 [0]),
        .I2(\ir_out_reg[7] [1]),
        .I3(pin[1]),
        .I4(Q[1]),
        .I5(\ir_out_reg[7] [0]),
        .O(\pin_reg[0][1]_0 ));
  LUT6 #(
    .INIT(64'hFCFCFC0CFA0A0A0A)) 
    \acc_out[2]_i_4 
       (.I0(O[2]),
        .I1(data4[2]),
        .I2(\ir_out_reg[7] [1]),
        .I3(pin[2]),
        .I4(Q[2]),
        .I5(\ir_out_reg[7] [0]),
        .O(\pin_reg[0][2]_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[3]_i_13 
       (.I0(\acc_out_reg[6] [1]),
        .I1(\acc_out_reg[4]_0 ),
        .O(\acc_out[3]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[3]_i_14 
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[7]),
        .I2(\acc_out_reg[4]_i_7_n_4 ),
        .O(\acc_out[3]_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h00AA003C)) 
    \acc_out[3]_i_4 
       (.I0(data4[3]),
        .I1(O[3]),
        .I2(\acc_out_reg[3] [0]),
        .I3(\ir_out_reg[7] [1]),
        .I4(\ir_out_reg[7] [0]),
        .O(\pin_reg[0][3]_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[4]_i_10 
       (.I0(\acc_out_reg[6] [2]),
        .I1(pin[6]),
        .I2(\acc_out_reg[5]_1 [3]),
        .O(\acc_out[4]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[4]_i_11 
       (.I0(\acc_out_reg[6] [2]),
        .I1(pin[5]),
        .I2(\acc_out_reg[5]_1 [2]),
        .O(\acc_out[4]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[4]_i_12 
       (.I0(\acc_out_reg[6] [2]),
        .I1(pin[4]),
        .I2(\acc_out_reg[5]_1 [1]),
        .O(\acc_out[4]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \acc_out[4]_i_13 
       (.I0(\acc_out_reg[6] [2]),
        .I1(pin[3]),
        .I2(\acc_out_reg[5]_1 [0]),
        .O(\acc_out[4]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \acc_out[4]_i_8 
       (.I0(\acc_out_reg[6] [2]),
        .I1(\acc_out_reg[5]_2 ),
        .O(\pin_reg[0][4]_0 ));
  LUT6 #(
    .INIT(64'hFCFCFC0CFA0A0A0A)) 
    \acc_out[6]_i_4 
       (.I0(\acc_out_reg[0] ),
        .I1(\acc_out_reg[6] [3]),
        .I2(\ir_out_reg[7] [1]),
        .I3(Q[6]),
        .I4(pin[6]),
        .I5(\ir_out_reg[7] [0]),
        .O(\pin_reg[0][6]_1 ));
  LUT5 #(
    .INIT(32'h00000400)) 
    \acc_out[7]_i_7 
       (.I0(pin[7]),
        .I1(\ir_out_reg[4] ),
        .I2(pin[6]),
        .I3(i___7_carry_i_9_n_0),
        .I4(pin[5]),
        .O(\pin_reg[0][7]_0 ));
  MUXF7 \acc_out_reg[0]_i_2 
       (.I0(\acc_out[0]_i_5_n_0 ),
        .I1(\acc_out[0]_i_6_n_0 ),
        .O(pin[0]),
        .S(\ir_out_reg[5] [2]));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \acc_out_reg[3]_i_8 
       (.CI(i___211_carry_i_15_n_0),
        .CO({\NLW_acc_out_reg[3]_i_8_CO_UNCONNECTED [3:2],data4[3],\NLW_acc_out_reg[3]_i_8_CO_UNCONNECTED [0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\acc_out_reg[6] [1],\acc_out_reg[4]_i_7_n_4 }),
        .O({\NLW_acc_out_reg[3]_i_8_O_UNCONNECTED [3:1],\acc_out_reg[3]_i_8_n_7 }),
        .S({1'b0,1'b0,\acc_out[3]_i_13_n_0 ,\acc_out[3]_i_14_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 \acc_out_reg[4]_i_7 
       (.CI(i___211_carry_i_26_n_0),
        .CO({CO,\NLW_acc_out_reg[4]_i_7_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI(\acc_out_reg[5]_1 ),
        .O({\acc_out_reg[4]_i_7_n_4 ,\acc_out_reg[4]_i_7_n_5 ,\acc_out_reg[4]_i_7_n_6 ,\acc_out_reg[4]_i_7_n_7 }),
        .S({\acc_out[4]_i_10_n_0 ,\acc_out[4]_i_11_n_0 ,\acc_out[4]_i_12_n_0 ,\acc_out[4]_i_13_n_0 }));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    i___0_carry__0_i_1
       (.I0(pin[0]),
        .I1(Q[5]),
        .I2(Q[3]),
        .I3(pin[2]),
        .I4(Q[4]),
        .I5(pin[1]),
        .O(\pin_reg[0][6]_2 [2]));
  MUXF7 i___0_carry__0_i_10
       (.I0(i___0_carry__0_i_16_n_0),
        .I1(i___0_carry__0_i_17_n_0),
        .O(pin[6]),
        .S(\ir_out_reg[5] [2]));
  MUXF7 i___0_carry__0_i_11
       (.I0(i___0_carry__0_i_18_n_0),
        .I1(i___0_carry__0_i_19_n_0),
        .O(pin[7]),
        .S(\ir_out_reg[5] [2]));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_12
       (.I0(\pin_reg[1] [5]),
        .I1(\pin_reg[3] [5]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [5]),
        .I5(\pin_reg[2] [5]),
        .O(i___0_carry__0_i_12_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_13
       (.I0(\pin_reg[5] [5]),
        .I1(\pin_reg[7] [5]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [5]),
        .I5(\pin_reg[6] [5]),
        .O(i___0_carry__0_i_13_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_14
       (.I0(\pin_reg[1] [4]),
        .I1(\pin_reg[3] [4]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [4]),
        .I5(\pin_reg[2] [4]),
        .O(i___0_carry__0_i_14_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_15
       (.I0(\pin_reg[5] [4]),
        .I1(\pin_reg[7] [4]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [4]),
        .I5(\pin_reg[6] [4]),
        .O(i___0_carry__0_i_15_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_16
       (.I0(\pin_reg[1] [6]),
        .I1(\pin_reg[3] [6]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [6]),
        .I5(\pin_reg[2] [6]),
        .O(i___0_carry__0_i_16_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_17
       (.I0(\pin_reg[5] [6]),
        .I1(\pin_reg[7] [6]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [6]),
        .I5(\pin_reg[6] [6]),
        .O(i___0_carry__0_i_17_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_18
       (.I0(\pin_reg[1] [7]),
        .I1(\pin_reg[3] [7]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [7]),
        .I5(\pin_reg[2] [7]),
        .O(i___0_carry__0_i_18_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry__0_i_19
       (.I0(\pin_reg[5] [7]),
        .I1(\pin_reg[7] [7]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [7]),
        .I5(\pin_reg[6] [7]),
        .O(i___0_carry__0_i_19_n_0));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    i___0_carry__0_i_2
       (.I0(pin[0]),
        .I1(Q[4]),
        .I2(Q[2]),
        .I3(pin[2]),
        .I4(Q[3]),
        .I5(pin[1]),
        .O(\pin_reg[0][6]_2 [1]));
  LUT6 #(
    .INIT(64'hF888800080008000)) 
    i___0_carry__0_i_3__0
       (.I0(pin[0]),
        .I1(Q[3]),
        .I2(Q[1]),
        .I3(pin[2]),
        .I4(Q[2]),
        .I5(pin[1]),
        .O(\pin_reg[0][6]_2 [0]));
  LUT5 #(
    .INIT(32'hC3C3D22D)) 
    i___0_carry__0_i_4
       (.I0(pin[6]),
        .I1(Q[6]),
        .I2(Q[7]),
        .I3(pin[7]),
        .I4(\ir_out_reg[7] [0]),
        .O(\pin_reg[0][7]_1 [2]));
  LUT6 #(
    .INIT(64'h70F7F7F78F080808)) 
    i___0_carry__0_i_4__0
       (.I0(pin[1]),
        .I1(Q[5]),
        .I2(\acc_out_reg[4] ),
        .I3(Q[6]),
        .I4(pin[0]),
        .I5(i___0_carry__0_i_9__0_n_0),
        .O(\pin_reg[0][6]_3 [3]));
  LUT5 #(
    .INIT(32'hC3C3D22D)) 
    i___0_carry__0_i_5
       (.I0(pin[5]),
        .I1(Q[5]),
        .I2(Q[6]),
        .I3(pin[6]),
        .I4(\ir_out_reg[7] [0]),
        .O(\pin_reg[0][7]_1 [1]));
  LUT6 #(
    .INIT(64'h956A6A956A956A95)) 
    i___0_carry__0_i_5__0
       (.I0(\pin_reg[0][6]_2 [2]),
        .I1(pin[1]),
        .I2(Q[5]),
        .I3(\acc_out_reg[4] ),
        .I4(Q[6]),
        .I5(pin[0]),
        .O(\pin_reg[0][6]_3 [2]));
  LUT5 #(
    .INIT(32'hC3C3D22D)) 
    i___0_carry__0_i_6
       (.I0(pin[4]),
        .I1(Q[4]),
        .I2(Q[5]),
        .I3(pin[5]),
        .I4(\ir_out_reg[7] [0]),
        .O(\pin_reg[0][7]_1 [0]));
  LUT6 #(
    .INIT(64'h956A6A956A956A95)) 
    i___0_carry__0_i_6__0
       (.I0(\pin_reg[0][6]_2 [1]),
        .I1(pin[1]),
        .I2(Q[4]),
        .I3(\acc_out_reg[3]_0 ),
        .I4(Q[5]),
        .I5(pin[0]),
        .O(\pin_reg[0][6]_3 [1]));
  LUT6 #(
    .INIT(64'h956A6A956A956A95)) 
    i___0_carry__0_i_7__0
       (.I0(\pin_reg[0][6]_2 [0]),
        .I1(pin[1]),
        .I2(Q[3]),
        .I3(\acc_out_reg[2]_0 ),
        .I4(Q[4]),
        .I5(pin[0]),
        .O(\pin_reg[0][6]_3 [0]));
  MUXF7 i___0_carry__0_i_8
       (.I0(i___0_carry__0_i_12_n_0),
        .I1(i___0_carry__0_i_13_n_0),
        .O(pin[5]),
        .S(\ir_out_reg[5] [2]));
  MUXF7 i___0_carry__0_i_9
       (.I0(i___0_carry__0_i_14_n_0),
        .I1(i___0_carry__0_i_15_n_0),
        .O(pin[4]),
        .S(\ir_out_reg[5] [2]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    i___0_carry__0_i_9__0
       (.I0(pin[0]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(pin[2]),
        .I4(Q[6]),
        .I5(pin[1]),
        .O(i___0_carry__0_i_9__0_n_0));
  MUXF7 i___0_carry_i_10
       (.I0(i___0_carry_i_14_n_0),
        .I1(i___0_carry_i_15_n_0),
        .O(pin[1]),
        .S(\ir_out_reg[5] [2]));
  MUXF7 i___0_carry_i_11
       (.I0(i___0_carry_i_16_n_0),
        .I1(i___0_carry_i_17_n_0),
        .O(pin[3]),
        .S(\ir_out_reg[5] [2]));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry_i_12
       (.I0(\pin_reg[1] [2]),
        .I1(\pin_reg[3] [2]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [2]),
        .I5(\pin_reg[2] [2]),
        .O(i___0_carry_i_12_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry_i_13
       (.I0(\pin_reg[5] [2]),
        .I1(\pin_reg[7] [2]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [2]),
        .I5(\pin_reg[6] [2]),
        .O(i___0_carry_i_13_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry_i_14
       (.I0(\pin_reg[1] [1]),
        .I1(\pin_reg[3] [1]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [1]),
        .I5(\pin_reg[2] [1]),
        .O(i___0_carry_i_14_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry_i_15
       (.I0(\pin_reg[5] [1]),
        .I1(\pin_reg[7] [1]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [1]),
        .I5(\pin_reg[6] [1]),
        .O(i___0_carry_i_15_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry_i_16
       (.I0(\pin_reg[1] [3]),
        .I1(\pin_reg[3] [3]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[0] [3]),
        .I5(\pin_reg[2] [3]),
        .O(i___0_carry_i_16_n_0));
  LUT6 #(
    .INIT(64'hCAFFCAF0CA0FCA00)) 
    i___0_carry_i_17
       (.I0(\pin_reg[5] [3]),
        .I1(\pin_reg[7] [3]),
        .I2(\ir_out_reg[5] [1]),
        .I3(\ir_out_reg[5] [0]),
        .I4(\pin_reg[4] [3]),
        .I5(\pin_reg[6] [3]),
        .O(i___0_carry_i_17_n_0));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    i___0_carry_i_1__0
       (.I0(pin[0]),
        .I1(Q[3]),
        .I2(Q[1]),
        .I3(pin[2]),
        .I4(Q[2]),
        .I5(pin[1]),
        .O(\pin_reg[0][3]_2 [1]));
  LUT4 #(
    .INIT(16'h7888)) 
    i___0_carry_i_2__0
       (.I0(pin[1]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(pin[2]),
        .O(\pin_reg[0][3]_2 [0]));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    i___0_carry_i_5__0
       (.I0(pin[2]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(pin[1]),
        .I4(pin[0]),
        .I5(Q[2]),
        .O(\pin_reg[0][3]_3 [1]));
  LUT4 #(
    .INIT(16'h7888)) 
    i___0_carry_i_6__0
       (.I0(pin[0]),
        .I1(Q[1]),
        .I2(pin[1]),
        .I3(Q[0]),
        .O(\pin_reg[0][3]_3 [0]));
  LUT5 #(
    .INIT(32'h3DC232CD)) 
    i___0_carry_i_7__0
       (.I0(pin[0]),
        .I1(Q[0]),
        .I2(\ir_out_reg[7] [0]),
        .I3(Q[1]),
        .I4(pin[1]),
        .O(S));
  MUXF7 i___0_carry_i_9
       (.I0(i___0_carry_i_12_n_0),
        .I1(i___0_carry_i_13_n_0),
        .O(pin[2]),
        .S(\ir_out_reg[5] [2]));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry__0_i_1
       (.CI(i___211_carry_i_2_n_0),
        .CO({i___211_carry__0_i_1_n_0,NLW_i___211_carry__0_i_1_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({i___211_carry_i_8_n_5,i___211_carry_i_8_n_6,i___211_carry_i_8_n_7,i___211_carry_i_11_n_4}),
        .O(\pin_reg[0][0]_2 ),
        .S({i___211_carry__0_i_6_n_0,i___211_carry__0_i_7_n_0,i___211_carry__0_i_8_n_0,i___211_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_2
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[7]),
        .I2(\pin_reg[0][0]_2 [3]),
        .O(\pin_reg[0][0]_4 [3]));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_3
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[6]),
        .I2(\pin_reg[0][0]_2 [2]),
        .O(\pin_reg[0][0]_4 [2]));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_4
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[5]),
        .I2(\pin_reg[0][0]_2 [1]),
        .O(\pin_reg[0][0]_4 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_5
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[4]),
        .I2(\pin_reg[0][0]_2 [0]),
        .O(\pin_reg[0][0]_4 [0]));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_6
       (.I0(data4[2]),
        .I1(pin[6]),
        .I2(i___211_carry_i_8_n_5),
        .O(i___211_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_7
       (.I0(data4[2]),
        .I1(pin[5]),
        .I2(i___211_carry_i_8_n_6),
        .O(i___211_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_8
       (.I0(data4[2]),
        .I1(pin[4]),
        .I2(i___211_carry_i_8_n_7),
        .O(i___211_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry__0_i_9
       (.I0(data4[2]),
        .I1(pin[3]),
        .I2(i___211_carry_i_11_n_4),
        .O(i___211_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___211_carry__1_i_1
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(i___211_carry_i_1_n_7),
        .O(\pin_reg[0][0]_5 ));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_1
       (.CI(i___211_carry__0_i_1_n_0),
        .CO({NLW_i___211_carry_i_1_CO_UNCONNECTED[3:2],\pin_reg[0][6]_0 [0],NLW_i___211_carry_i_1_CO_UNCONNECTED[0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,data4[2],i___211_carry_i_8_n_4}),
        .O({NLW_i___211_carry_i_1_O_UNCONNECTED[3:1],i___211_carry_i_1_n_7}),
        .S({1'b0,1'b0,i___211_carry_i_9_n_0,i___211_carry_i_10_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_10
       (.I0(data4[2]),
        .I1(pin[7]),
        .I2(i___211_carry_i_8_n_4),
        .O(i___211_carry_i_10_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_11
       (.CI(1'b0),
        .CO({i___211_carry_i_11_n_0,NLW_i___211_carry_i_11_CO_UNCONNECTED[2:0]}),
        .CYINIT(data4[3]),
        .DI({i___211_carry_i_18_n_5,i___211_carry_i_18_n_6,Q[2],1'b0}),
        .O({i___211_carry_i_11_n_4,i___211_carry_i_11_n_5,i___211_carry_i_11_n_6,NLW_i___211_carry_i_11_O_UNCONNECTED[0]}),
        .S({i___211_carry_i_23_n_0,i___211_carry_i_24_n_0,i___211_carry_i_25_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_12
       (.I0(data4[2]),
        .I1(pin[2]),
        .I2(i___211_carry_i_11_n_5),
        .O(i___211_carry_i_12_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_13
       (.I0(data4[2]),
        .I1(pin[1]),
        .I2(i___211_carry_i_11_n_6),
        .O(i___211_carry_i_13_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_14
       (.I0(data4[2]),
        .I1(pin[0]),
        .I2(Q[1]),
        .O(i___211_carry_i_14_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_15
       (.CI(i___211_carry_i_18_n_0),
        .CO({i___211_carry_i_15_n_0,NLW_i___211_carry_i_15_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({\acc_out_reg[4]_i_7_n_5 ,\acc_out_reg[4]_i_7_n_6 ,\acc_out_reg[4]_i_7_n_7 ,i___211_carry_i_26_n_4}),
        .O({i___211_carry_i_15_n_4,i___211_carry_i_15_n_5,i___211_carry_i_15_n_6,i___211_carry_i_15_n_7}),
        .S({i___211_carry_i_27_n_0,i___211_carry_i_28_n_0,i___211_carry_i_29_n_0,i___211_carry_i_30_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    i___211_carry_i_16
       (.I0(data4[3]),
        .I1(\acc_out_reg[3]_i_8_n_7 ),
        .O(i___211_carry_i_16_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_17
       (.I0(data4[3]),
        .I1(pin[7]),
        .I2(i___211_carry_i_15_n_4),
        .O(i___211_carry_i_17_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_18
       (.CI(1'b0),
        .CO({i___211_carry_i_18_n_0,NLW_i___211_carry_i_18_CO_UNCONNECTED[2:0]}),
        .CYINIT(\acc_out_reg[6] [1]),
        .DI({i___211_carry_i_26_n_5,i___211_carry_i_26_n_6,Q[3],1'b0}),
        .O({i___211_carry_i_18_n_4,i___211_carry_i_18_n_5,i___211_carry_i_18_n_6,NLW_i___211_carry_i_18_O_UNCONNECTED[0]}),
        .S({i___211_carry_i_31_n_0,i___211_carry_i_32_n_0,i___211_carry_i_33_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_19
       (.I0(data4[3]),
        .I1(pin[6]),
        .I2(i___211_carry_i_15_n_5),
        .O(i___211_carry_i_19_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_2
       (.CI(1'b0),
        .CO({i___211_carry_i_2_n_0,NLW_i___211_carry_i_2_CO_UNCONNECTED[2:0]}),
        .CYINIT(data4[2]),
        .DI({i___211_carry_i_11_n_5,i___211_carry_i_11_n_6,Q[1],1'b0}),
        .O({\pin_reg[0][0]_1 ,NLW_i___211_carry_i_2_O_UNCONNECTED[0]}),
        .S({i___211_carry_i_12_n_0,i___211_carry_i_13_n_0,i___211_carry_i_14_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_20
       (.I0(data4[3]),
        .I1(pin[5]),
        .I2(i___211_carry_i_15_n_6),
        .O(i___211_carry_i_20_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_21
       (.I0(data4[3]),
        .I1(pin[4]),
        .I2(i___211_carry_i_15_n_7),
        .O(i___211_carry_i_21_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_22
       (.I0(data4[3]),
        .I1(pin[3]),
        .I2(i___211_carry_i_18_n_4),
        .O(i___211_carry_i_22_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_23
       (.I0(data4[3]),
        .I1(pin[2]),
        .I2(i___211_carry_i_18_n_5),
        .O(i___211_carry_i_23_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_24
       (.I0(data4[3]),
        .I1(pin[1]),
        .I2(i___211_carry_i_18_n_6),
        .O(i___211_carry_i_24_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_25
       (.I0(data4[3]),
        .I1(pin[0]),
        .I2(Q[2]),
        .O(i___211_carry_i_25_n_0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_26
       (.CI(1'b0),
        .CO({i___211_carry_i_26_n_0,NLW_i___211_carry_i_26_CO_UNCONNECTED[2:0]}),
        .CYINIT(\acc_out_reg[6] [2]),
        .DI({\acc_out_reg[5]_0 ,Q[4],1'b0}),
        .O({i___211_carry_i_26_n_4,i___211_carry_i_26_n_5,i___211_carry_i_26_n_6,NLW_i___211_carry_i_26_O_UNCONNECTED[0]}),
        .S({i___211_carry_i_34_n_0,i___211_carry_i_35_n_0,i___211_carry_i_36_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_27
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[6]),
        .I2(\acc_out_reg[4]_i_7_n_5 ),
        .O(i___211_carry_i_27_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_28
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[5]),
        .I2(\acc_out_reg[4]_i_7_n_6 ),
        .O(i___211_carry_i_28_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_29
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[4]),
        .I2(\acc_out_reg[4]_i_7_n_7 ),
        .O(i___211_carry_i_29_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_3
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[3]),
        .I2(\pin_reg[0][0]_1 [2]),
        .O(\pin_reg[0][0]_3 [3]));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_30
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[3]),
        .I2(i___211_carry_i_26_n_4),
        .O(i___211_carry_i_30_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_31
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[2]),
        .I2(i___211_carry_i_26_n_5),
        .O(i___211_carry_i_31_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_32
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[1]),
        .I2(i___211_carry_i_26_n_6),
        .O(i___211_carry_i_32_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_33
       (.I0(\acc_out_reg[6] [1]),
        .I1(pin[0]),
        .I2(Q[3]),
        .O(i___211_carry_i_33_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_34
       (.I0(\acc_out_reg[6] [2]),
        .I1(pin[2]),
        .I2(\acc_out_reg[5]_0 [1]),
        .O(i___211_carry_i_34_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_35
       (.I0(\acc_out_reg[6] [2]),
        .I1(pin[1]),
        .I2(\acc_out_reg[5]_0 [0]),
        .O(i___211_carry_i_35_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_36
       (.I0(\acc_out_reg[6] [2]),
        .I1(pin[0]),
        .I2(Q[4]),
        .O(i___211_carry_i_36_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_4
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[2]),
        .I2(\pin_reg[0][0]_1 [1]),
        .O(\pin_reg[0][0]_3 [2]));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_5
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[1]),
        .I2(\pin_reg[0][0]_1 [0]),
        .O(\pin_reg[0][0]_3 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    i___211_carry_i_6
       (.I0(\pin_reg[0][6]_0 [0]),
        .I1(pin[0]),
        .I2(Q[0]),
        .O(\pin_reg[0][0]_3 [0]));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_7
       (.CI(i___211_carry_i_8_n_0),
        .CO({NLW_i___211_carry_i_7_CO_UNCONNECTED[3:2],data4[2],NLW_i___211_carry_i_7_CO_UNCONNECTED[0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,data4[3],i___211_carry_i_15_n_4}),
        .O({NLW_i___211_carry_i_7_O_UNCONNECTED[3:1],i___211_carry_i_7_n_7}),
        .S({1'b0,1'b0,i___211_carry_i_16_n_0,i___211_carry_i_17_n_0}));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-8 {cell *THIS*}}" *) 
  CARRY4 i___211_carry_i_8
       (.CI(i___211_carry_i_11_n_0),
        .CO({i___211_carry_i_8_n_0,NLW_i___211_carry_i_8_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({i___211_carry_i_15_n_5,i___211_carry_i_15_n_6,i___211_carry_i_15_n_7,i___211_carry_i_18_n_4}),
        .O({i___211_carry_i_8_n_4,i___211_carry_i_8_n_5,i___211_carry_i_8_n_6,i___211_carry_i_8_n_7}),
        .S({i___211_carry_i_19_n_0,i___211_carry_i_20_n_0,i___211_carry_i_21_n_0,i___211_carry_i_22_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    i___211_carry_i_9
       (.I0(data4[2]),
        .I1(i___211_carry_i_7_n_7),
        .O(i___211_carry_i_9_n_0));
  LUT6 #(
    .INIT(64'h70F7F7F78F080808)) 
    i___22_carry__0_i_1
       (.I0(pin[4]),
        .I1(Q[2]),
        .I2(\acc_out_reg[1] ),
        .I3(Q[3]),
        .I4(pin[3]),
        .I5(i___22_carry__0_i_3_n_0),
        .O(\pin_reg[0][7]_3 ));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    i___22_carry__0_i_3
       (.I0(pin[3]),
        .I1(Q[4]),
        .I2(Q[2]),
        .I3(pin[5]),
        .I4(Q[3]),
        .I5(pin[4]),
        .O(i___22_carry__0_i_3_n_0));
  LUT6 #(
    .INIT(64'h8777788878887888)) 
    i___22_carry_i_1
       (.I0(pin[3]),
        .I1(Q[3]),
        .I2(Q[1]),
        .I3(pin[5]),
        .I4(Q[2]),
        .I5(pin[4]),
        .O(\pin_reg[0][3]_1 [1]));
  LUT4 #(
    .INIT(16'h7888)) 
    i___22_carry_i_2
       (.I0(pin[4]),
        .I1(Q[1]),
        .I2(pin[5]),
        .I3(Q[0]),
        .O(\pin_reg[0][3]_1 [0]));
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    i___22_carry_i_4
       (.I0(\pin_reg[0][3]_1 [1]),
        .I1(pin[5]),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(pin[4]),
        .O(\pin_reg[0][3]_4 [1]));
  LUT4 #(
    .INIT(16'h7888)) 
    i___22_carry_i_6
       (.I0(pin[3]),
        .I1(Q[1]),
        .I2(pin[4]),
        .I3(Q[0]),
        .O(\pin_reg[0][3]_4 [0]));
  LUT5 #(
    .INIT(32'h69999666)) 
    i___35_carry__0_i_1
       (.I0(\acc_out_reg[5] [1]),
        .I1(\acc_out_reg[2] ),
        .I2(Q[0]),
        .I3(pin[7]),
        .I4(i___35_carry__0_i_2_n_0),
        .O(\pin_reg[0][7]_2 ));
  LUT4 #(
    .INIT(16'h7888)) 
    i___35_carry__0_i_2
       (.I0(\acc_out_reg[5] [0]),
        .I1(\acc_out_reg[3] [1]),
        .I2(pin[6]),
        .I3(Q[1]),
        .O(i___35_carry__0_i_2_n_0));
  LUT4 #(
    .INIT(16'h9666)) 
    i___35_carry_i_2
       (.I0(\acc_out_reg[3] [1]),
        .I1(\acc_out_reg[5] [0]),
        .I2(pin[6]),
        .I3(Q[0]),
        .O(\pin_reg[0][6]_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    i___7_carry__0_i_1
       (.I0(pin[7]),
        .I1(\pin_reg[0][6]_0 [1]),
        .O(\pin_reg[0][6]_8 [3]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT4 #(
    .INIT(16'h0045)) 
    i___7_carry__0_i_10
       (.I0(pin[1]),
        .I1(Q[7]),
        .I2(pin[0]),
        .I3(pin[2]),
        .O(i___7_carry__0_i_10_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    i___7_carry__0_i_2
       (.I0(pin[6]),
        .I1(\pin_reg[0][6]_0 [1]),
        .O(\pin_reg[0][6]_8 [2]));
  LUT2 #(
    .INIT(4'h6)) 
    i___7_carry__0_i_3
       (.I0(pin[5]),
        .I1(\pin_reg[0][6]_0 [1]),
        .O(\pin_reg[0][6]_8 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    i___7_carry__0_i_4
       (.I0(pin[4]),
        .I1(\pin_reg[0][6]_0 [1]),
        .O(\pin_reg[0][6]_8 [0]));
  LUT4 #(
    .INIT(16'h9979)) 
    i___7_carry__0_i_5
       (.I0(pin[7]),
        .I1(pin[6]),
        .I2(i___7_carry_i_9_n_0),
        .I3(pin[5]),
        .O(\pin_reg[0][6]_7 [3]));
  LUT4 #(
    .INIT(16'h5BA5)) 
    i___7_carry__0_i_6
       (.I0(pin[6]),
        .I1(pin[7]),
        .I2(pin[5]),
        .I3(i___7_carry_i_9_n_0),
        .O(\pin_reg[0][6]_7 [2]));
  LUT4 #(
    .INIT(16'h9669)) 
    i___7_carry__0_i_7
       (.I0(\pin_reg[0][6]_0 [1]),
        .I1(pin[5]),
        .I2(pin[4]),
        .I3(i___7_carry__0_i_9_n_0),
        .O(\pin_reg[0][6]_7 [1]));
  LUT4 #(
    .INIT(16'h9669)) 
    i___7_carry__0_i_8
       (.I0(\pin_reg[0][6]_0 [1]),
        .I1(pin[4]),
        .I2(pin[3]),
        .I3(i___7_carry__0_i_10_n_0),
        .O(\pin_reg[0][6]_7 [0]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h00000051)) 
    i___7_carry__0_i_9
       (.I0(pin[2]),
        .I1(pin[0]),
        .I2(Q[7]),
        .I3(pin[1]),
        .I4(pin[3]),
        .O(i___7_carry__0_i_9_n_0));
  LUT4 #(
    .INIT(16'h0004)) 
    i___7_carry__1_i_1
       (.I0(pin[5]),
        .I1(i___7_carry_i_9_n_0),
        .I2(pin[6]),
        .I3(pin[7]),
        .O(\pin_reg[0][6]_9 ));
  LUT4 #(
    .INIT(16'h04FF)) 
    i___7_carry__1_i_2
       (.I0(pin[5]),
        .I1(i___7_carry_i_9_n_0),
        .I2(pin[6]),
        .I3(pin[7]),
        .O(\pin_reg[0][6]_10 ));
  LUT4 #(
    .INIT(16'h0004)) 
    i___7_carry_i_1
       (.I0(pin[5]),
        .I1(i___7_carry_i_9_n_0),
        .I2(pin[6]),
        .I3(pin[7]),
        .O(\pin_reg[0][6]_0 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    i___7_carry_i_2
       (.I0(pin[3]),
        .I1(\pin_reg[0][6]_0 [1]),
        .O(\pin_reg[0][6]_6 [2]));
  LUT2 #(
    .INIT(4'h6)) 
    i___7_carry_i_3
       (.I0(pin[2]),
        .I1(\pin_reg[0][6]_0 [1]),
        .O(\pin_reg[0][6]_6 [1]));
  LUT2 #(
    .INIT(4'h6)) 
    i___7_carry_i_4
       (.I0(pin[1]),
        .I1(\pin_reg[0][6]_0 [1]),
        .O(\pin_reg[0][6]_6 [0]));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    i___7_carry_i_5
       (.I0(\pin_reg[0][6]_0 [1]),
        .I1(pin[3]),
        .I2(pin[2]),
        .I3(pin[0]),
        .I4(Q[7]),
        .I5(pin[1]),
        .O(\pin_reg[0][6]_5 [3]));
  LUT5 #(
    .INIT(32'h96699696)) 
    i___7_carry_i_6
       (.I0(\pin_reg[0][6]_0 [1]),
        .I1(pin[2]),
        .I2(pin[1]),
        .I3(Q[7]),
        .I4(pin[0]),
        .O(\pin_reg[0][6]_5 [2]));
  LUT4 #(
    .INIT(16'h6996)) 
    i___7_carry_i_7
       (.I0(\pin_reg[0][6]_0 [1]),
        .I1(pin[1]),
        .I2(pin[0]),
        .I3(Q[7]),
        .O(\pin_reg[0][6]_5 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    i___7_carry_i_8
       (.I0(\pin_reg[0][6]_0 [1]),
        .I1(pin[0]),
        .I2(Q[6]),
        .O(\pin_reg[0][6]_5 [0]));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    i___7_carry_i_9
       (.I0(pin[3]),
        .I1(pin[1]),
        .I2(Q[7]),
        .I3(pin[0]),
        .I4(pin[2]),
        .I5(pin[4]),
        .O(i___7_carry_i_9_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[0]),
        .Q(\pin_reg[0] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[1]),
        .Q(\pin_reg[0] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[2]),
        .Q(\pin_reg[0] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[3]),
        .Q(\pin_reg[0] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[4]),
        .Q(\pin_reg[0] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[5]),
        .Q(\pin_reg[0] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[6]),
        .Q(\pin_reg[0] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[0][7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[7]),
        .Q(\pin_reg[0] [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][0] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[0]),
        .Q(\pin_reg[1] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][1] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[1]),
        .Q(\pin_reg[1] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][2] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[2]),
        .Q(\pin_reg[1] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][3] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[3]),
        .Q(\pin_reg[1] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][4] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[4]),
        .Q(\pin_reg[1] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][5] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[5]),
        .Q(\pin_reg[1] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][6] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[6]),
        .Q(\pin_reg[1] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[1][7] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2] ),
        .D(D[7]),
        .Q(\pin_reg[1] [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][0] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[0]),
        .Q(\pin_reg[2] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][1] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[1]),
        .Q(\pin_reg[2] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][2] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[2]),
        .Q(\pin_reg[2] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][3] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[3]),
        .Q(\pin_reg[2] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][4] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[4]),
        .Q(\pin_reg[2] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][5] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[5]),
        .Q(\pin_reg[2] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][6] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[6]),
        .Q(\pin_reg[2] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[2][7] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_0 ),
        .D(D[7]),
        .Q(\pin_reg[2] [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][0] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[0]),
        .Q(\pin_reg[3] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][1] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[1]),
        .Q(\pin_reg[3] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][2] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[2]),
        .Q(\pin_reg[3] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][3] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[3]),
        .Q(\pin_reg[3] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][4] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[4]),
        .Q(\pin_reg[3] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][5] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[5]),
        .Q(\pin_reg[3] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][6] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[6]),
        .Q(\pin_reg[3] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[3][7] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_1 ),
        .D(D[7]),
        .Q(\pin_reg[3] [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][0] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[0]),
        .Q(\pin_reg[4] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][1] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[1]),
        .Q(\pin_reg[4] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][2] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[2]),
        .Q(\pin_reg[4] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][3] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[3]),
        .Q(\pin_reg[4] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][4] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[4]),
        .Q(\pin_reg[4] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][5] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[5]),
        .Q(\pin_reg[4] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][6] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[6]),
        .Q(\pin_reg[4] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[4][7] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0] ),
        .D(D[7]),
        .Q(\pin_reg[4] [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][0] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[0]),
        .Q(\pin_reg[5] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][1] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[1]),
        .Q(\pin_reg[5] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][2] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[2]),
        .Q(\pin_reg[5] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][3] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[3]),
        .Q(\pin_reg[5] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][4] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[4]),
        .Q(\pin_reg[5] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][5] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[5]),
        .Q(\pin_reg[5] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][6] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[6]),
        .Q(\pin_reg[5] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[5][7] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_2 ),
        .D(D[7]),
        .Q(\pin_reg[5] [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][0] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[0]),
        .Q(\pin_reg[6] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][1] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[1]),
        .Q(\pin_reg[6] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][2] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[2]),
        .Q(\pin_reg[6] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][3] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[3]),
        .Q(\pin_reg[6] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][4] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[4]),
        .Q(\pin_reg[6] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][5] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[5]),
        .Q(\pin_reg[6] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][6] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[6]),
        .Q(\pin_reg[6] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[6][7] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[0]_0 ),
        .D(D[7]),
        .Q(\pin_reg[6] [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][0] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[0]),
        .Q(\pin_reg[7] [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][1] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[1]),
        .Q(\pin_reg[7] [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][2] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[2]),
        .Q(\pin_reg[7] [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][3] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[3]),
        .Q(\pin_reg[7] [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][4] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[4]),
        .Q(\pin_reg[7] [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][5] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[5]),
        .Q(\pin_reg[7] [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][6] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[6]),
        .Q(\pin_reg[7] [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pin_reg[7][7] 
       (.C(clk_IBUF_BUFG),
        .CE(\ir_out_reg[2]_3 ),
        .D(D[7]),
        .Q(\pin_reg[7] [7]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
