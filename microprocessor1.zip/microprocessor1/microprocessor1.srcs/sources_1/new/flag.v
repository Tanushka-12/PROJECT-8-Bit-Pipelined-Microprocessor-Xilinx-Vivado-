`timescale 1ns / 1ps

// Zero, Carry, and Auxiliary-Carry flags
//DEclarating of the flags value
module flags_register(
    input  wire clk,
    input  wire rst,
    input  wire update,           
    input  wire alu_zero,
    input  wire alu_carry,
    input  wire alu_aux_carry,
    output reg  zero_flag,
    output reg  carry_flag,
    output reg  auxiliary_carry_flag
);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            zero_flag <= 0;
            carry_flag<= 0;
            auxiliary_carry_flag<= 0;
        end else if (update) begin
            zero_flag<= alu_zero;
            carry_flag<= alu_carry;
            auxiliary_carry_flag<= alu_aux_carry;
        end
    end

endmodule