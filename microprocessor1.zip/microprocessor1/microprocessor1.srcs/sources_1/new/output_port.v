`timescale 1ns / 1ps

//Output port values declartion
// Assigning values to use it to display the values on the hardware/board

module output_port(
    input  wire clk,    //clock
    input  wire rst,    //reset
    input  wire write,  //write
    input  wire [7:0] data_in,   //input data
    output reg [7:0] port_out    //output port
);

    always @(posedge clk or posedge rst) begin
        if (rst)                  //if reset=1 then
            port_out <= 8'h00;    //output port=0
        else if (write)             //if write =1 then
            port_out <= data_in;   //output port=input data
    end

endmodule