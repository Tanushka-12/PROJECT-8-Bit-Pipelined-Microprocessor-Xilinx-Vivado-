`timescale 1ns / 1ps

//Arithmetic logic unit(ALU)

module alu(
    input [7:0] A,              //Input1
    input [7:0] B,              //Input2
    input [3:0] opcode,         //Opcode for different operations
    output reg [7:0] result,    //result
    output zero_flag,           //Zero flag i.e. Z=1(if result is zero) else Z=0
    output carry_flag,          //Carry flag i.e. C=1(if result[8]=0) otherwise C=0
    output auxiliary_carry_flag //Auxilary carry flag i.e. AC=1 if result[3:0]>1111(F) otherwise AC=0
);
    reg [8:0] full_sum;         //Total sum

    always @(*) begin
        full_sum = 9'b0;
        case (opcode)
            4'b0000: begin                               // Addition
                full_sum = {1'b0,A} + {1'b0,B};         //output=input1+input2
                result   = full_sum[7:0];               //result=output=total sum
            end
            4'b0001: begin                               // Increment
                full_sum = {1'b0,A} + 9'b1;              //output=input+1
                result   = full_sum[7:0];                //result=output=total sum
            end
            4'b0010: result = A - B;                    // Substraction i.e. result=input1 - input2
            4'b0011: result = A - 1;                    // Decrement i.e. result=input - 1
            4'b0100: result = A * B;                    // Multiplication i.e.result = input1 * input2
            4'b0101: result = A / B;                    // Division i.e. result = input 1 / input2
            4'b0110: result = A & B;                    // AND
            4'b0111: result = A | B;                    // OR
            4'b1000: result = A ^ B;                    // XOR
            default: result = 8'h00;
        endcase
    end

    assign zero_flag = (result == 8'h00);                   //Zero flag i.e. Z=1(if result is zero) else Z=0
    assign carry_flag = full_sum[8];                        //Carry flag i.e. C=1(if result[8]=0) otherwise C=0
    assign auxiliary_carry_flag= (A[3:0] + B[3:0]) > 4'hF;  //Auxilary carry flag i.e. AC=1 if result[3:0]>1111(F) otherwise AC=0

endmodule