`timescale 1ns / 1ps

//Instruction memory

module instruction_memory(
    input wire clk,             //clock
    input wire [7:0]addr,       //address
    output reg [7:0]instr_word  //instruction word/data
);
    reg [7:0] mem [0:255];      //memory

    integer i;
    initial begin
        for (i=0;i<256;i=i+1)   //loop repeating 256 times
        mem[i]=8'h00;       
        
//program the CPU will execute (program starts at address 0)
        mem[0] = 8'hB8;  // LOAD  
        mem[1] = 8'hB1;  // MOV   
        mem[2] = 8'hB9;  // LOAD  
        mem[3] = 8'h01;  // ADD   
        mem[4] = 8'hF0;  // OUT  
        mem[5] = 8'hCC;  // JMP   
        mem[8] = 8'h0A;  // 10 
        mem[9] = 8'h14;  // 20 
    end

    always @(posedge clk)
        instr_word <= mem[addr];    //instruction word=address of the instruction to be loaded

endmodule