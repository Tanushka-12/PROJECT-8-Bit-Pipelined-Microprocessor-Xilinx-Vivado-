`timescale 1ns / 1ps

// The accumulator is a 8-bit register which holds the result of the last ALU operation.

module accumulator(
    input wire clk,         //clock
    input wire rst,         //reset
    input wire load,        //load (It loads the current data)
    input wire [7:0] data_in,//data_in is the input data
    output reg [7:0] acc_out //Accumulator data
);

    always @(posedge clk or posedge rst) begin      //whenever positive-edge and positive-reset is there this loop will be followed
        if (rst)                        //if reset=1 then 
            acc_out <= 8'h00;           //accumulator output=0
        else if (load)              //else load the data 
            acc_out <= data_in;     //accumulator output=input data
    end

endmodule