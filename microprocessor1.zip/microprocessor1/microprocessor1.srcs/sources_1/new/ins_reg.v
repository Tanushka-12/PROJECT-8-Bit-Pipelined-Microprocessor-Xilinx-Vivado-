`timescale 1ns / 1ps

module instruction_register(
    input wire clk,     //clock
    input wire rst,     //reset
    input wire load,    //loading/selecting the data
    input wire [7:0]data_in,   //input data
    output reg [7:0]ir_out     // instruction outputv([7:4] = opcode,[3:0] = operand)
);
    always @(posedge clk or posedge rst) begin
        if (rst)           //if reset=1 then
        ir_out <= 8'h00;   //instruction output=0
        else if (load)     //if data is loaded then 
        ir_out <= data_in; //instruction output=input data
    end 

endmodule