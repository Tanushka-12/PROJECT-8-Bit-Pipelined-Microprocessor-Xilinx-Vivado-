`timescale 1ns / 1ps

//top module 
//but adding and designing extra functions / modules through bus and calling/Instantiation of it ( such as UART )is still left

module microprocessor_top(
    input  wire clk,
    input  wire  rst,
    output wire [7:0] port_out
);
    wire [7:0] pc_addr, instr_word, ir_out;
    wire [7:0] reg_data_out, alu_result, acc_out;
    wire [7:0] mar_addr, mdr_data, mem_data_out;
    wire [3:0] alu_opcode;
    wire alu_zero, alu_carry, alu_aux;
    wire zf, cf, acf;
    wire pc_inc, pc_load;
    wire ir_load, mem_read, mem_write;
    wire reg_write, acc_load;
    wire mar_load, mdr_load;
    wire out_write;

    program_counter PC( .clk (clk), .rst (rst),   .load(pc_load),  .inc (pc_inc),   .jump_addr(ir_out[7:0]),      .pc_out(pc_addr) );

    instruction_memory IMEM(.clk (clk), .addr(pc_addr),  .instr_word(instr_word) );

    instruction_register IR( .clk(clk),    .rst(rst),  .load (ir_load),  .data_in (instr_word),  .ir_out  (ir_out) );

    control_unit CU(  .clk (clk),   .rst (rst),     .opcode(ir_out[7:4]),  .zero_flag (zf),
        .carry_flag(cf),.pc_inc (pc_inc),.pc_load (pc_load),.ir_load(ir_load), .mem_read (mem_read),   .mem_write (mem_write),
        .reg_write (reg_write), .acc_load  (acc_load), .alu_op    (alu_opcode),  .mar_load  (mar_load),  .mdr_load  (mdr_load), .out_write (out_write) );

    register REG( .clk (clk),.data_in (alu_result),.sel_in (ir_out[2:0]), .sel_out (ir_out[5:3]),.enable (reg_write), .output_port(1'b1),.data_out(reg_data_out));

    alu ALU(.A (acc_out), .B (reg_data_out),.opcode(alu_opcode),.result(alu_result), .zero_flag (alu_zero),   .carry_flag (alu_carry),  .auxiliary_carry_flag(alu_aux) );

    accumulator ACC(.clk (clk), .rst (rst), .load (acc_load), .data_in (alu_result), .acc_out (acc_out));

    flags_register FLAGS( .clk(clk),.rst(rst),.update(acc_load), .alu_zero(alu_zero),.alu_carry(alu_carry), .alu_aux_carry (alu_aux),.zero_flag(zf),.carry_flag (cf),.auxiliary_carry_flag(acf) );

    mar_mdr MARR( .clk(clk),.rst (rst), .mar_load (mar_load),.mdr_load (mdr_load),.addr_in  (ir_out[7:0]), .data_in  (mem_data_out), .mar_out  (mar_addr),.mdr_out  (mdr_data)  );

    data_memory DMEM(.clk(clk),.mem_read (mem_read),.mem_write(mem_write), .addr(mar_addr),.data_in(acc_out),.data_out (mem_data_out)  );

    output_port OUTP(.clk (clk),.rst (rst),.write (out_write),.data_in (acc_out), .port_out(port_out) );

endmodule