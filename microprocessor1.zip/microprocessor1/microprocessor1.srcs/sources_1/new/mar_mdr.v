`timescale 1ns / 1ps

// Memory address register holds the address currently being accessed.
// Memory data register holds data read from or to be written to memory.

module mar_mdr(
    input wire clk,
    input wire rst,
    input wire mar_load,
    input wire mdr_load,
    input wire [7:0] addr_in,
    input wire [7:0] data_in,
    output reg [7:0] mar_out,
    output reg [7:0] mdr_out
);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            mar_out <= 8'h00;
            mdr_out <= 8'h00;
        end else begin
            if (mar_load) 
            mar_out <= addr_in;
            if (mdr_load) 
            mdr_out <= data_in;
        end
    end

endmodule