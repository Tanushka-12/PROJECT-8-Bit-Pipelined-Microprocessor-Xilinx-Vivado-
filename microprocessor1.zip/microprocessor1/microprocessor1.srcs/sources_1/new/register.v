`timescale 1ns / 1ps

//Register

module register(
    input  wire clk,            //clock
    input  wire [7:0] data_in,  //input data
    input  wire [2:0] sel_in,   //selected input
    input  wire [2:0] sel_out,  //selected output
    input  wire enable,     //enable
    input  wire output_port,  //output port
    output wire [7:0] data_out  //output data
);

    // 8 general-purpose registers or ports;each port having 8 pins to store each bit
    reg [7:0] pin [0:7];

    always @(posedge clk) begin
        if (enable)     //if enable=1
            pin[sel_in] <= data_in;   // Data is stored in the selected pin
    end

    
assign data_out = (output_port) ? pin[sel_out] : 8'bz;   //output is high-impedance when output_port is low
wire [7:0] pin_0, pin_1, pin_2, pin_3,pin_4, pin_5, pin_6, pin_7;  //Declaring the pins of size 8
    
//Each port has  8 pins ;each each bit is stored in a single pin
//there are total 8 pins and they are assigned values from the register
    assign pin_0 = pin[0];
    assign pin_1 = pin[1];
    assign pin_2 = pin[2];
    assign pin_3 = pin[3];
    assign pin_4 = pin[4];
    assign pin_5 = pin[5];
    assign pin_6 = pin[6];
    assign pin_7 = pin[7];

endmodule