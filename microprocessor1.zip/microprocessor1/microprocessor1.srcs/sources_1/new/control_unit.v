`timescale 1ns / 1ps

module control_unit(
    input  wire clk,          //clock
    input  wire rst,          //reset
    input  wire [3:0]opcode,  //opcode
    input  wire zero_flag,    //zero flag
    input  wire carry_flag,   //Carry flag

// Program counter control
    output reg pc_inc,      //program counter increment
    output reg pc_load,     //loading program counter data

    // Instruction register/ memory control
    output reg ir_load,
    output reg mem_read,       //memory read
    output reg mem_write,      //memory write

    // Register file controls
    output reg reg_write,
    output reg acc_load,   // load result into accumulator
    output reg [3:0] alu_op,  // ALU opcode 

    // Memory address register and memory data register
    output reg mar_load,
    output reg mdr_load,
    output reg out_write   // Output port write
);

    // Pipelining instruction state encoding
    localparam FETCH= 2'b00;
    localparam DECODE= 2'b01;
    localparam EXECUTE= 2'b10;

    // Instruction opcodes 
    localparam OP_ADD= 4'b0000;     //Addition
    localparam OP_INC= 4'b0001;     //Increment
    localparam OP_SUB= 4'b0010;     //Subtraction
    localparam OP_DEC= 4'b0011;     //Decrement
    localparam OP_MUL= 4'b0100;     //Multiplication
    localparam OP_DIV= 4'b0101;     //Division
    localparam OP_AND= 4'b0110;     //AND
    localparam OP_OR= 4'b0111;      //OR
    localparam OP_XOR= 4'b1000;     //XOR
    localparam OP_LOAD= 4'b1001;   //load from data memory
    localparam OP_STORE= 4'b1010;   //store to data memory
    localparam OP_MOV= 4'b1011;   //move reg to reg
    localparam OP_JMP= 4'b1100;   //unconditional jump
    localparam OP_JZ= 4'b1101;   //jump if zero
    localparam OP_JC= 4'b1110;   //jump if carry
    localparam OP_OUT= 4'b1111;   //write Accumulator data to output port

    reg [1:0] state;

    always @(posedge clk or posedge rst) begin
        if (rst)
            state <= FETCH;
        else begin
        //Declaration of pipelining instruction
            case (state)
                FETCH:state <= DECODE;
                DECODE:state <= EXECUTE;
                EXECUTE:state <= FETCH;
                default: state <= FETCH;
            endcase
        end
    end

    always @(*) begin
        pc_inc= 0; 
        pc_load = 0;
        ir_load= 0; 
        mem_read= 0; 
        mem_write= 0;
        reg_write= 0; 
        acc_load= 0;
        mar_load= 0; 
        mdr_load =0;
        out_write = 0;
        alu_op = 4'b0000;

        case (state)
        //Fetching data instructions
            FETCH: begin
                mem_read = 1;
                ir_load  = 1;
                pc_inc   = 1;   
            end
       //Decoding data instructions
            DECODE: begin
                mar_load = 1;
            end
         //Execute data instructions
            EXECUTE: begin
                case (opcode)
                    OP_ADD, OP_INC,OP_SUB, OP_DEC, OP_MUL, OP_DIV,OP_AND, OP_OR, OP_XOR: begin
                        alu_op   = opcode;
                        acc_load = 1;   
                        reg_write= 1;
                    end

                    OP_LOAD: begin
                        mem_read  = 1;
                        mdr_load  = 1;
                        acc_load  = 1;
                    end

                    OP_STORE: begin
                        mem_write = 1;
                    end

                    OP_MOV: begin
                        reg_write = 1;
                    end

                    OP_JMP: begin
                        pc_load = 1;
                    end

                    OP_JZ: begin
                        if (zero_flag)  pc_load = 1;
                        else            pc_inc  = 1;
                    end

                    OP_JC: begin
                        if (carry_flag) pc_load = 1;
                        else            pc_inc  = 1;
                    end

                    OP_OUT: begin
                        out_write = 1;
                    end

                    default: ; 
                endcase
            end

            default: ;
        endcase
    end

endmodule