`timescale 1ns / 1ps

module program_counter(
    input wire clk,                 //clock
    input wire rst,                 //reset
    input wire load,                //load is the data we are loading/using
    input wire inc,                 //increment
    input wire [7:0] jump_addr,     //address we are jumping/moving to
    output reg [7:0] pc_out         //program counter output
);
    always @(posedge clk or posedge rst) begin
        if (rst)                //if reset=1 then
        pc_out <= 8'h00;        //program counter output=0
        else if (load)          //else if (load) then
        pc_out <= jump_addr;    //program counter output=jumped address
        else if (inc)           //else if incremented then
        pc_out <= pc_out + 1;   //program counter output=program counter output+1
    end

endmodule