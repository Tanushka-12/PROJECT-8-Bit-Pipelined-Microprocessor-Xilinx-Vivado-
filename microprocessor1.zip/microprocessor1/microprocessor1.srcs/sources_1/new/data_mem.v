`timescale 1ns / 1ps

module data_memory(
    input wire clk,           //clock
    input wire mem_read,      //memory read
    input wire mem_write,     //memory write
    input wire [7:0]addr,     //address
    input wire [7:0]data_in,  //input data
    output reg [7:0]data_out  //output data
);

    reg [7:0] ram [0:255];   //RAM (Random access Memory ) of size 256 bytes

    integer i;
    initial begin
        for (i = 0; i < 256; i = i + 1)  //loop repeating 256 times 
            ram[i]=8'h00;           //ram[i]=0
    end

    always @(posedge clk) begin
        if (mem_write)               //if memory address is writtten then 
            ram[addr] <= data_in;    //ram[address]=input data

        if (mem_read)                //else if memory address is read then
            data_out <= ram[addr];   //output data=ram[address]
    end

endmodule