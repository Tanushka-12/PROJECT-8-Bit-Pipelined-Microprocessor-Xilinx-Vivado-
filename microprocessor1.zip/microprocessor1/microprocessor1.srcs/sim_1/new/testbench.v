`timescale 1ns / 1ps

module tb_microprocessor;

    reg clk, rst;
    wire [7:0] port_out;

    microprocessor_top DUT(.clk(clk),.rst(rst),.port_out(port_out) );
    initial      
    clk =1'b0;
    always #5    
    clk =~clk;

    initial begin
        #200_000;
        $finish;
    end

    integer cycles;

    initial begin
        $display(" 8-bit Microprocessor Simulation");

        rst = 1'b1;
        repeat(10) @(posedge clk); 
        #1;
        rst = 1'b0;
 
        cycles = 0;
        while (port_out === 8'h00 && cycles < 200) begin
            @(posedge clk); #1;
            cycles = cycles + 1;
        end

        rst = 1'b1;
        repeat(10) @(posedge clk); #1;
        rst = 1'b0;
        $display("[%0t ns] Mid-run reset", $time);

        cycles = 0;
        while (port_out === 8'h00 && cycles < 200) begin
            @(posedge clk); #1;
            cycles = cycles + 1;
        end
        $finish;
    end

endmodule